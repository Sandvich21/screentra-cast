Screentra Cast player-client bundle. Run payload/install/player-client.sh.
This bundle contains no client identity, credentials, layouts, uploads, or runtime state.
