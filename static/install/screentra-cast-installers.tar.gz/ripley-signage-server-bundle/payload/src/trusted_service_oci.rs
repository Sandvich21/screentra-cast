use crate::trusted_service_runtime::{
    ActivationGate, TrustedServiceRuntimeRecord, EXECUTION_ENABLED,
};
use sha2::{Digest, Sha256};
use std::collections::BTreeSet;
use std::fs;
use std::path::Path;

pub const SUPPORTED_ROOTLESS_RUNTIMES: &[&str] = &["podman", "nerdctl"];
pub const MAX_OCI_COMMAND_ARGS: usize = 64;
pub const MAX_OCI_COMMAND_PART_BYTES: usize = 256;
pub const MAX_OCI_COMMAND_BYTES: usize = 4 * 1024;
pub const MAX_OCI_ARGV_BYTES: usize = 4 * 1024;
pub const MAX_OCI_ALLOWED_REGISTRIES: usize = 64;
pub const REQUIRED_OCI_ACTIVATION_GATES: &[&str] = &[
    "manifest_signature",
    "image_signature",
    "administrator_approval",
    "execution_backend",
    "credential_broker",
    "database_boundary",
    "controlled_gateway",
    "resource_policy",
    "network_boundary",
    "readiness_handshake",
    "audit",
    "image_transport",
    "lifecycle_rollback",
    "cleanup",
    "dedicated_host",
];

pub fn validate_oci_activation_gate_records(gates: &[ActivationGate]) -> Result<(), String> {
    let mut seen = BTreeSet::new();
    if gates.iter().any(|gate| {
        gate.name.is_empty()
            || gate.name.len() > 128
            || gate.name.chars().any(|character| character.is_control())
            || gate.reason.is_empty()
            || gate.reason.len() > 512
            || gate.reason.chars().any(|character| character.is_control())
            || !REQUIRED_OCI_ACTIVATION_GATES.contains(&gate.name.as_str())
            || !seen.insert(&gate.name)
    }) {
        return Err("OCI activation gates are malformed or duplicated".to_string());
    }
    if REQUIRED_OCI_ACTIVATION_GATES
        .iter()
        .any(|required| !gates.iter().any(|gate| gate.name == *required))
    {
        return Err("Trusted service activation gates are incomplete".to_string());
    }
    Ok(())
}

pub fn validate_oci_activation_gates(gates: &[ActivationGate]) -> Result<(), String> {
    validate_oci_activation_gate_records(gates)?;
    if REQUIRED_OCI_ACTIVATION_GATES.iter().any(|required| {
        !gates
            .iter()
            .any(|gate| gate.name == *required && gate.passed)
    }) {
        return Err("Trusted service activation gates are incomplete".to_string());
    }
    Ok(())
}

pub fn validate_oci_approval_metadata(record: &TrustedServiceRuntimeRecord) -> Result<(), String> {
    let approver = record
        .approved_by
        .as_deref()
        .ok_or_else(|| "Trusted service approval metadata is incomplete".to_string())?;
    if approver.is_empty()
        || approver.len() > 128
        || approver.chars().any(|character| character.is_control())
    {
        return Err("Trusted service approval metadata is invalid".to_string());
    }
    let approved_at = record
        .approved_at
        .as_deref()
        .ok_or_else(|| "Trusted service approval metadata is incomplete".to_string())?;
    if approved_at.len() > 64
        || approved_at.chars().any(|character| character.is_control())
        || chrono::DateTime::parse_from_rfc3339(approved_at).is_err()
    {
        return Err("Trusted service approval metadata is invalid".to_string());
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciRuntimeProbeReport {
    pub runtime_name: Option<String>,
    pub executable_present: bool,
    pub can_start: bool,
    pub blocked_by: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct OciRuntimeIdentity {
    pub device: u64,
    pub inode: u64,
}

pub fn runtime_path_identity(path: &Path) -> Option<OciRuntimeIdentity> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        let metadata = fs::symlink_metadata(path).ok()?;
        if !metadata.file_type().is_file() {
            return None;
        }
        return Some(OciRuntimeIdentity {
            device: metadata.dev(),
            inode: metadata.ino(),
        });
    }
    #[cfg(not(unix))]
    {
        let _ = path;
        None
    }
}

pub fn probe_oci_runtime(path: &Path) -> OciRuntimeProbeReport {
    let runtime_name = path
        .file_name()
        .and_then(|value| value.to_str())
        .map(str::to_string);
    let mut blocked_by = Vec::new();
    if !path.is_absolute() {
        blocked_by.push("runtime path must be absolute".to_string());
    }
    if !runtime_name
        .as_deref()
        .is_some_and(|name| SUPPORTED_ROOTLESS_RUNTIMES.contains(&name))
    {
        blocked_by.push("unsupported rootless runtime".to_string());
    }
    let contains_symlink = path.is_absolute() && path_contains_symlink(path);
    let insecure_permissions = path.is_absolute() && path_has_insecure_permissions(path);
    if contains_symlink {
        blocked_by.push("runtime path contains a symlink".to_string());
    }
    if insecure_permissions {
        blocked_by.push("runtime path is writable by group or others".to_string());
    }
    let executable_present = path.is_absolute()
        && !contains_symlink
        && !insecure_permissions
        && path
            .symlink_metadata()
            .map(is_regular_executable)
            .unwrap_or(false);
    if !executable_present {
        blocked_by.push("runtime executable unavailable".to_string());
    }
    // Capability probing and execution remain intentionally disabled until the
    // separately reviewed OCI supervisor, gateway, and resource policy exist.
    blocked_by.push("OCI capability probe is not enabled".to_string());
    OciRuntimeProbeReport {
        runtime_name,
        executable_present,
        can_start: false,
        blocked_by,
    }
}

fn path_contains_symlink(path: &Path) -> bool {
    path.ancestors().any(|ancestor| {
        fs::symlink_metadata(ancestor)
            .map(|metadata| metadata.file_type().is_symlink())
            .unwrap_or(false)
    })
}

fn path_has_insecure_permissions(path: &Path) -> bool {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        return path.ancestors().any(|ancestor| {
            let Ok(metadata) = fs::symlink_metadata(ancestor) else {
                return true;
            };
            let mode = metadata.permissions().mode();
            if metadata.is_dir() {
                let writable_by_untrusted = mode & 0o022 != 0;
                let protected_by_sticky_bit = mode & 0o1000 != 0;
                writable_by_untrusted && !protected_by_sticky_bit
            } else {
                mode & 0o022 != 0
            }
        });
    }
    #[cfg(not(unix))]
    {
        let _ = path;
        false
    }
}

fn is_regular_executable(metadata: std::fs::Metadata) -> bool {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        return metadata.file_type().is_file() && metadata.permissions().mode() & 0o111 != 0;
    }
    #[cfg(not(unix))]
    {
        metadata.file_type().is_file()
    }
}

fn launch_profile_matches(
    spec: &OciLaunchSpec,
    profile: &crate::addons::TrustedServiceLaunchProfile,
) -> bool {
    spec.command == profile.command
        && spec.gateway_socket_path == profile.gateway_socket_path
        && spec.policy.rootless == profile.rootless
        && spec.policy.non_root == profile.non_root
        && spec.policy.network_disabled == profile.network_disabled
        && spec.policy.read_only_rootfs == profile.read_only_rootfs
        && spec.policy.no_new_privileges == profile.no_new_privileges
        && spec.policy.drop_all_capabilities == profile.drop_all_capabilities
        && spec.policy.seccomp_default == profile.seccomp_default
        && spec.resources.memory_bytes == profile.memory_bytes
        && spec.resources.cpu_millis == profile.cpu_millis
        && spec.resources.pids == profile.pids
        && spec.resources.writable_bytes == profile.writable_bytes
}

pub fn validate_oci_launch_spec_against_record(
    spec: &OciLaunchSpec,
    record: &TrustedServiceRuntimeRecord,
) -> Result<(), String> {
    if !EXECUTION_ENABLED || record.state != "approved" || !record.execution_enabled {
        return Err("Trusted service execution is disabled".to_string());
    }
    if record.approved_by.is_none() || validate_oci_activation_gates(&record.gates).is_err() {
        return Err("Trusted service activation gates are incomplete".to_string());
    }
    if validate_oci_approval_metadata(record).is_err() {
        return Err("Trusted service approval metadata is invalid".to_string());
    }
    if spec.addon_id != record.addon_id
        || spec.activation_instance != record.activation_instance
        || spec.image != record.image
        || spec.image_digest != record.image_digest
        || spec.capabilities != record.capabilities
        || spec.storage_namespace != record.storage_namespace
        || spec.api_namespace != record.api_namespace
        || !launch_profile_matches(spec, &record.launch_profile)
    {
        return Err("OCI launch spec does not match the approved activation".to_string());
    }
    validate_oci_launch_spec(spec)
}

pub fn validate_oci_launch_spec_against_record_with_registry_policy(
    spec: &OciLaunchSpec,
    record: &TrustedServiceRuntimeRecord,
    registry_policy: &OciRegistryPolicy,
) -> Result<(), String> {
    validate_oci_launch_spec_against_record(spec, record)?;
    validate_oci_image_registry(&spec.image, registry_policy)
}

fn default_seccomp_option(runtime_name: &str) -> String {
    match runtime_name {
        "podman" => "--security-opt=seccomp=/usr/share/containers/seccomp.json".to_string(),
        "nerdctl" => "--security-opt=seccomp=default".to_string(),
        _ => "--security-opt=seccomp=default".to_string(),
    }
}

fn validate_built_argv(argv: &[String]) -> Result<(), String> {
    if argv.is_empty()
        || argv.len() > MAX_OCI_COMMAND_ARGS + 16
        || argv
            .iter()
            .any(|part| part.is_empty() || part.len() > MAX_OCI_COMMAND_PART_BYTES * 2)
    {
        return Err("OCI runtime argv contains an invalid argument".to_string());
    }
    let total_bytes = argv
        .iter()
        .try_fold(0usize, |total, part| total.checked_add(part.len()));
    if total_bytes.map_or(true, |bytes| bytes > MAX_OCI_ARGV_BYTES) {
        return Err("OCI runtime argv exceeds the bounded payload size".to_string());
    }
    Ok(())
}

pub fn build_rootless_argv(
    runtime_name: &str,
    spec: &OciLaunchSpec,
) -> Result<Vec<String>, String> {
    validate_oci_launch_spec(spec)?;
    if !SUPPORTED_ROOTLESS_RUNTIMES.contains(&runtime_name) {
        return Err("unsupported rootless runtime".to_string());
    }
    let mut argv = vec![runtime_name.to_string(), "run".to_string()];
    argv.extend([
        "--rm".to_string(),
        "--pull=never".to_string(),
        format!("--name={}", container_name(spec)),
        "--network=none".to_string(),
        "--read-only".to_string(),
        "--user=65532:65532".to_string(),
        "--cap-drop=ALL".to_string(),
        "--security-opt=no-new-privileges".to_string(),
        default_seccomp_option(runtime_name),
        format!("--tmpfs=/tmp:rw,size={}", spec.resources.writable_bytes),
        format!("--pids-limit={}", spec.resources.pids),
        format!("--memory={}", spec.resources.memory_bytes),
        format!(
            "--cpus={}.{:03}",
            spec.resources.cpu_millis / 1_000,
            spec.resources.cpu_millis % 1_000
        ),
        format!("{}@{}", spec.image, spec.image_digest),
    ]);
    argv.extend(spec.command.iter().cloned());
    validate_built_argv(&argv)?;
    Ok(argv)
}

pub fn build_rootless_argv_for_path(
    runtime_path: &Path,
    spec: &OciLaunchSpec,
) -> Result<Vec<String>, String> {
    let report = probe_oci_runtime(runtime_path);
    if !report.executable_present {
        return Err("rootless runtime executable is unavailable".to_string());
    }
    let runtime_name = report
        .runtime_name
        .as_deref()
        .ok_or_else(|| "rootless runtime name is unavailable".to_string())?;
    let mut argv = build_rootless_argv(runtime_name, spec)?;
    argv[0] = runtime_path.to_string_lossy().into_owned();
    validate_built_argv(&argv)?;
    Ok(argv)
}

fn container_name(spec: &OciLaunchSpec) -> String {
    let identity = format!("{}:{}", spec.addon_id, spec.activation_instance);
    let digest = format!("{:x}", Sha256::digest(identity.as_bytes()));
    let prefix = format!("{}-{}", spec.addon_id, spec.activation_instance)
        .chars()
        .map(|ch| if ch == '.' || ch == '_' { '-' } else { ch })
        .filter(|ch| ch.is_ascii_alphanumeric() || *ch == '-')
        .take(35)
        .collect::<String>();
    let prefix = if prefix.is_empty() { "addon" } else { &prefix };
    format!("screentra-{prefix}-{}", &digest[..16])
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciLaunchPolicy {
    pub rootless: bool,
    pub non_root: bool,
    pub network_disabled: bool,
    pub read_only_rootfs: bool,
    pub no_new_privileges: bool,
    pub drop_all_capabilities: bool,
    pub seccomp_default: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciResourceLimits {
    pub memory_bytes: u64,
    pub cpu_millis: u32,
    pub pids: u32,
    pub writable_bytes: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciLaunchSpec {
    pub addon_id: String,
    pub activation_instance: String,
    pub image: String,
    pub image_digest: String,
    pub capabilities: Vec<String>,
    pub storage_namespace: String,
    pub api_namespace: String,
    pub gateway_socket_path: String,
    pub command: Vec<String>,
    pub environment: Vec<(String, String)>,
    pub host_mounts: Vec<String>,
    pub published_ports: Vec<u16>,
    pub policy: OciLaunchPolicy,
    pub resources: OciResourceLimits,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciResourcePolicyEvidence {
    pub rootless: bool,
    pub uid: u32,
    pub network_none: bool,
    pub read_only_rootfs: bool,
    pub no_new_privileges: bool,
    pub capabilities_dropped: bool,
    pub seccomp_default: bool,
    pub memory_bytes: u64,
    pub cpu_millis: u32,
    pub pids: u32,
    pub writable_bytes: u64,
}

pub fn validate_oci_resource_policy_evidence(
    spec: &OciLaunchSpec,
    evidence: &OciResourcePolicyEvidence,
) -> Result<(), String> {
    validate_oci_launch_spec(spec)?;
    if !evidence.rootless
        || evidence.uid == 0
        || !evidence.network_none
        || !evidence.read_only_rootfs
        || !evidence.no_new_privileges
        || !evidence.capabilities_dropped
        || !evidence.seccomp_default
        || evidence.memory_bytes != spec.resources.memory_bytes
        || evidence.cpu_millis != spec.resources.cpu_millis
        || evidence.pids != spec.resources.pids
        || evidence.writable_bytes != spec.resources.writable_bytes
    {
        return Err("OCI runtime resource-policy evidence does not match the approved launch spec".to_string());
    }
    Ok(())
}

fn is_shell_command(part: &str) -> bool {
    let executable = Path::new(part)
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or(part);
    matches!(
        executable,
        "sh" | "bash"
            | "dash"
            | "zsh"
            | "ksh"
            | "fish"
            | "csh"
            | "tcsh"
            | "pwsh"
            | "powershell"
            | "cmd"
            | "cmd.exe"
    )
}

pub fn validate_oci_launch_spec(spec: &OciLaunchSpec) -> Result<(), String> {
    crate::addons::validate_addon_storage_namespace(&spec.addon_id)?;
    crate::addons::validate_addon_storage_namespace(&spec.activation_instance)
        .map_err(|_| "Invalid activation instance".to_string())?;
    crate::addons::validate_trusted_service_image_reference(&spec.image)
        .map_err(|_| "OCI image must be a qualified immutable reference".to_string())?;
    let digest = spec
        .image_digest
        .strip_prefix("sha256:")
        .ok_or_else(|| "OCI image digest must use lowercase sha256".to_string())?;
    if digest.len() != 64
        || !digest
            .chars()
            .all(|ch| ch.is_ascii_hexdigit() && !ch.is_ascii_uppercase())
    {
        return Err("OCI image digest must be lowercase sha256".to_string());
    }
    if spec.storage_namespace != spec.addon_id || spec.api_namespace != spec.addon_id {
        return Err("OCI namespaces must bind to the addon identity".to_string());
    }
    crate::addons::validate_addon_storage_namespace(&spec.storage_namespace)?;
    crate::addons::validate_addon_storage_namespace(&spec.api_namespace)?;
    if spec.gateway_socket_path != crate::trusted_service_gateway::GATEWAY_SOCKET_PATH {
        return Err("OCI gateway endpoint is not controlled".to_string());
    }
    let mut seen = BTreeSet::new();
    if spec.capabilities.len() > crate::trusted_service_runtime::TRUSTED_SERVICE_CAPABILITIES.len()
    {
        return Err("OCI capabilities are unsupported or duplicated".to_string());
    }
    for capability in &spec.capabilities {
        if !crate::trusted_service_runtime::TRUSTED_SERVICE_CAPABILITIES
            .contains(&capability.as_str())
            || !seen.insert(capability)
        {
            return Err("OCI capabilities are unsupported or duplicated".to_string());
        }
    }
    let command_bytes = spec
        .command
        .iter()
        .try_fold(0usize, |total, part| total.checked_add(part.len()));
    if spec.command.is_empty()
        || spec.command.len() > MAX_OCI_COMMAND_ARGS
        || command_bytes.map_or(true, |bytes| bytes > MAX_OCI_COMMAND_BYTES)
        || spec
            .command
            .iter()
            .any(|part| part.len() > MAX_OCI_COMMAND_PART_BYTES)
        || spec.command.iter().any(|part| {
            part.is_empty()
                || part.chars().any(|ch| ch.is_control())
                || is_shell_command(part)
                || matches!(part.as_str(), "-c" | "-lc")
        })
    {
        return Err("OCI command must not invoke a shell".to_string());
    }
    if !spec.environment.is_empty()
        || !spec.host_mounts.is_empty()
        || !spec.published_ports.is_empty()
    {
        return Err("OCI launch spec exposes a forbidden host boundary".to_string());
    }
    if !spec.policy.rootless
        || !spec.policy.non_root
        || !spec.policy.network_disabled
        || !spec.policy.read_only_rootfs
        || !spec.policy.no_new_privileges
        || !spec.policy.drop_all_capabilities
        || !spec.policy.seccomp_default
    {
        return Err("OCI isolation policy is incomplete".to_string());
    }
    if spec.resources.memory_bytes == 0
        || spec.resources.memory_bytes > 4 * 1024 * 1024 * 1024
        || spec.resources.cpu_millis == 0
        || spec.resources.cpu_millis > 16_000
        || spec.resources.pids == 0
        || spec.resources.pids > 4_096
        || spec.resources.writable_bytes == 0
        || spec.resources.writable_bytes > 1024 * 1024 * 1024
    {
        return Err("OCI resource limits are invalid".to_string());
    }
    Ok(())
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OciRegistryPolicy {
    pub allowed_registries: BTreeSet<String>,
}

pub fn validate_oci_registry_policy(policy: &OciRegistryPolicy) -> Result<(), String> {
    if policy.allowed_registries.is_empty()
        || policy.allowed_registries.len() > MAX_OCI_ALLOWED_REGISTRIES
        || policy.allowed_registries.iter().any(|registry| {
            registry.is_empty()
                || registry.len() > 255
                || registry.contains('/')
                || registry.contains(':')
                || registry.contains('@')
                || registry.contains("..")
                || registry.starts_with('.')
                || registry.ends_with('.')
                || registry.starts_with('-')
                || registry.ends_with('-')
                || registry.split('.').any(|label| {
                    label.is_empty()
                        || label.starts_with('-')
                        || label.ends_with('-')
                        || !label
                            .chars()
                            .all(|character| character.is_ascii_alphanumeric() || character == '-')
                })
                || registry
                    .chars()
                    .any(|character| character.is_whitespace() || character.is_control())
                || registry != &registry.to_ascii_lowercase()
        })
    {
        return Err("OCI registry allowlist is invalid".to_string());
    }
    Ok(())
}

pub fn validate_oci_image_registry(image: &str, policy: &OciRegistryPolicy) -> Result<(), String> {
    crate::addons::validate_trusted_service_image_reference(image)
        .map_err(|_| "OCI image reference is invalid".to_string())?;
    validate_oci_registry_policy(policy)?;
    let (registry, repository) = image
        .split_once('/')
        .ok_or_else(|| "OCI image must use an allowlisted registry".to_string())?;
    if repository.is_empty()
        || repository.starts_with('/')
        || repository.contains("//")
        || repository.contains(':')
        || repository.contains('@')
        || repository
            .chars()
            .any(|character| character.is_whitespace() || character.is_control())
        || repository
            .split('/')
            .any(|part| part == "." || part == "..")
    {
        return Err("OCI image repository path is invalid".to_string());
    }
    if !policy.allowed_registries.contains(registry) {
        return Err("OCI image registry is not allowlisted".to_string());
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeSet;
    use std::fs;
    use std::path::Path;
    use uuid::Uuid;

    use super::{
        build_rootless_argv, build_rootless_argv_for_path, container_name, launch_profile_matches,
        probe_oci_runtime,
        validate_oci_activation_gate_records, validate_oci_activation_gates,
        validate_oci_approval_metadata, validate_oci_image_registry, validate_oci_launch_spec,
        validate_oci_launch_spec_against_record, ActivationGate, OciLaunchPolicy, OciLaunchSpec,
        OciRegistryPolicy, OciResourceLimits, TrustedServiceRuntimeRecord,
        MAX_OCI_ALLOWED_REGISTRIES, MAX_OCI_COMMAND_ARGS, MAX_OCI_COMMAND_PART_BYTES,
        REQUIRED_OCI_ACTIVATION_GATES,
    };

    fn safe_spec() -> OciLaunchSpec {
        OciLaunchSpec {
            addon_id: "example.weather".to_string(),
            activation_instance: "activation-1".to_string(),
            image: "registry.example/weather".to_string(),
            image_digest: format!("sha256:{}", "a".repeat(64)),
            capabilities: vec!["storage".to_string()],
            storage_namespace: "example.weather".to_string(),
            api_namespace: "example.weather".to_string(),
            gateway_socket_path: crate::trusted_service_gateway::GATEWAY_SOCKET_PATH.to_string(),
            command: vec!["/service".to_string()],
            environment: Vec::new(),
            host_mounts: Vec::new(),
            published_ports: Vec::new(),
            policy: OciLaunchPolicy {
                rootless: true,
                non_root: true,
                network_disabled: true,
                read_only_rootfs: true,
                no_new_privileges: true,
                drop_all_capabilities: true,
                seccomp_default: true,
            },
            resources: OciResourceLimits {
                memory_bytes: 256 * 1024 * 1024,
                cpu_millis: 500,
                pids: 64,
                writable_bytes: 16 * 1024 * 1024,
            },
        }
    }

    #[test]
    fn resource_policy_evidence_must_match_the_approved_launch_spec() {
        let spec = safe_spec();
        let evidence = super::OciResourcePolicyEvidence {
            rootless: true,
            uid: 65532,
            network_none: true,
            read_only_rootfs: true,
            no_new_privileges: true,
            capabilities_dropped: true,
            seccomp_default: true,
            memory_bytes: spec.resources.memory_bytes,
            cpu_millis: spec.resources.cpu_millis,
            pids: spec.resources.pids,
            writable_bytes: spec.resources.writable_bytes,
        };
        super::validate_oci_resource_policy_evidence(&spec, &evidence)
            .expect("matching resource evidence should pass");
        let mut wrong_uid = evidence.clone();
        wrong_uid.uid = 0;
        assert!(super::validate_oci_resource_policy_evidence(&spec, &wrong_uid).is_err());
        let mut wrong_memory = evidence;
        wrong_memory.memory_bytes += 1;
        assert!(super::validate_oci_resource_policy_evidence(&spec, &wrong_memory).is_err());
    }

    #[test]
    fn accepts_immutable_rootless_launch_spec() {
        validate_oci_launch_spec(&safe_spec()).expect("safe OCI spec should validate");
    }

    #[test]
    fn rootless_argv_rejects_an_oversized_final_payload() {
        let mut spec = safe_spec();
        spec.command = vec!["x".repeat(MAX_OCI_COMMAND_PART_BYTES); MAX_OCI_COMMAND_ARGS / 4];
        assert!(
            super::build_rootless_argv("podman", &spec).is_err(),
            "the complete runtime argv must remain bounded"
        );
    }

    #[test]
    fn activation_gate_validation_rejects_duplicates_and_incomplete_passes() {
        let complete = REQUIRED_OCI_ACTIVATION_GATES
            .iter()
            .map(|name| ActivationGate {
                name: (*name).to_string(),
                passed: true,
                reason: "verified".to_string(),
            })
            .collect::<Vec<_>>();
        validate_oci_activation_gates(&complete).expect("complete gates should pass");

        let mut duplicate = complete.clone();
        duplicate.push(ActivationGate {
            name: "image_signature".to_string(),
            passed: false,
            reason: "conflict".to_string(),
        });
        assert!(validate_oci_activation_gates(&duplicate).is_err());

        let mut unknown = complete.clone();
        unknown.push(ActivationGate {
            name: "future_gate".to_string(),
            passed: true,
            reason: "unexpected".to_string(),
        });
        assert!(validate_oci_activation_gates(&unknown).is_err());

        let mut malformed_reason = complete.clone();
        malformed_reason[0].reason = "bad\nreason".to_string();
        assert!(validate_oci_activation_gates(&malformed_reason).is_err());

        let mut empty_reason = complete.clone();
        empty_reason[0].reason.clear();
        assert!(validate_oci_activation_gates(&empty_reason).is_err());

        let mut incomplete = complete;
        incomplete[0].passed = false;
        assert!(validate_oci_activation_gates(&incomplete).is_err());
        let mut missing = incomplete.clone();
        missing.pop();
        assert!(validate_oci_activation_gate_records(&missing).is_err());
    }

    #[test]
    fn registry_policy_requires_an_explicit_allowlisted_registry() {
        let policy = OciRegistryPolicy {
            allowed_registries: BTreeSet::from(["registry.example".to_string()]),
        };
        validate_oci_image_registry("registry.example/weather", &policy)
            .expect("allowlisted registry should pass");
        assert!(validate_oci_image_registry("docker.io/weather", &policy).is_err());
        assert!(validate_oci_image_registry("weather", &policy).is_err());
        assert!(validate_oci_image_registry("registry.example/../weather", &policy).is_err());
        assert!(validate_oci_image_registry("registry.example/weather:latest", &policy).is_err());
        assert!(validate_oci_image_registry("registry.example/weather image", &policy).is_err());
        assert!(validate_oci_image_registry("registry.example/weather!", &policy).is_err());

        let invalid_policy = OciRegistryPolicy {
            allowed_registries: BTreeSet::from(["Registry.Example".to_string()]),
        };
        assert!(validate_oci_image_registry("registry.example/weather", &invalid_policy).is_err());

        let malformed_policy = OciRegistryPolicy {
            allowed_registries: BTreeSet::from(["registry!.example".to_string()]),
        };
        assert!(
            validate_oci_image_registry("registry.example/weather", &malformed_policy).is_err()
        );

        let oversized_policy = OciRegistryPolicy {
            allowed_registries: (0..=MAX_OCI_ALLOWED_REGISTRIES)
                .map(|index| format!("registry{index}.example"))
                .collect(),
        };
        assert!(
            validate_oci_image_registry("registry.example/weather", &oversized_policy).is_err()
        );
    }

    #[test]
    fn rejects_mutable_image_tags_and_noncanonical_digests() {
        let mut mutable = safe_spec();
        mutable.image = "registry.example/weather:latest".to_string();
        assert!(validate_oci_launch_spec(&mutable).is_err());

        let mut unqualified = safe_spec();
        unqualified.image = "weather".to_string();
        assert!(validate_oci_launch_spec(&unqualified).is_err());

        let mut absolute = safe_spec();
        absolute.image = "/registry.example/weather".to_string();
        assert!(validate_oci_launch_spec(&absolute).is_err());

        let mut dot_component = safe_spec();
        dot_component.image = "registry.example/.".to_string();
        assert!(validate_oci_launch_spec(&dot_component).is_err());

        let mut uppercase = safe_spec();
        uppercase.image_digest = format!("sha256:{}", "A".repeat(64));
        assert!(validate_oci_launch_spec(&uppercase).is_err());
    }

    #[test]
    fn rejects_host_exposure_shell_execution_and_environment() {
        let mut exposed = safe_spec();
        exposed.host_mounts.push("/etc:/etc".to_string());
        assert!(validate_oci_launch_spec(&exposed).is_err());

        let mut port = safe_spec();
        port.published_ports.push(8080);
        assert!(validate_oci_launch_spec(&port).is_err());

        let mut shell = safe_spec();
        shell.command = vec!["/bin/sh".to_string(), "-c".to_string(), "run".to_string()];
        assert!(validate_oci_launch_spec(&shell).is_err());

        let mut alternate_shell = safe_spec();
        alternate_shell.command = vec!["/bin/zsh".to_string()];
        assert!(validate_oci_launch_spec(&alternate_shell).is_err());

        let mut environment = safe_spec();
        environment
            .environment
            .push(("TOKEN".to_string(), "secret".to_string()));
        assert!(validate_oci_launch_spec(&environment).is_err());

        let mut oversized_part = safe_spec();
        oversized_part.command = vec!["x".repeat(MAX_OCI_COMMAND_PART_BYTES + 1)];
        assert!(validate_oci_launch_spec(&oversized_part).is_err());

        let mut too_many_args = safe_spec();
        too_many_args.command = (0..=MAX_OCI_COMMAND_ARGS)
            .map(|_| "/service".to_string())
            .collect();
        assert!(validate_oci_launch_spec(&too_many_args).is_err());
    }

    #[test]
    fn rejects_duplicate_capabilities_and_invalid_identity() {
        let mut duplicate = safe_spec();
        duplicate.capabilities.push("storage".to_string());
        assert!(validate_oci_launch_spec(&duplicate).is_err());

        let mut invalid = safe_spec();
        invalid.activation_instance = "../other".to_string();
        assert!(validate_oci_launch_spec(&invalid).is_err());

        let mut gateway = safe_spec();
        gateway.gateway_socket_path = "/tmp/host.sock".to_string();
        assert!(validate_oci_launch_spec(&gateway).is_err());
    }

    #[test]
    fn builds_fixed_rootless_argv_without_shell_or_host_boundaries() {
        let args = build_rootless_argv("podman", &safe_spec()).expect("argv should validate");
        assert_eq!(args.first().map(String::as_str), Some("podman"));
        assert!(args
            .windows(2)
            .any(|pair| pair == ["--network=none", "--read-only"]));
        assert!(args.iter().any(|arg| arg == "--pull=never"));
        assert!(args.iter().any(|arg| arg == "--cap-drop=ALL"));
        assert!(args.iter().any(|arg| arg == "--user=65532:65532"));
        assert!(args
            .iter()
            .any(|arg| arg == "--security-opt=seccomp=/usr/share/containers/seccomp.json"));
        assert!(args
            .iter()
            .any(|arg| arg == "--tmpfs=/tmp:rw,size=16777216"));
        assert!(args
            .iter()
            .any(|arg| arg == "--security-opt=no-new-privileges"));
        assert!(args.iter().any(|arg| arg == "registry.example/weather@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        assert_eq!(args.last().map(String::as_str), Some("/service"));
        assert!(!args
            .iter()
            .any(|arg| arg == "-c" || arg == "--volume" || arg == "-v"));
    }

    #[cfg(unix)]
    #[test]
    fn explicit_runtime_path_builder_rechecks_final_argv_bounds() {
        use std::os::unix::fs::PermissionsExt;
        let base = std::env::temp_dir().join(format!(
            "screentra-oci-long-{}",
            uuid::Uuid::new_v4()
        ));
        let mut root = base.clone();
        for _ in 0..18 {
            root = root.join(format!("n{}", "a".repeat(200)));
        }
        fs::create_dir_all(&root).expect("long runtime fixture directory should be created");
        for ancestor in root.ancestors().take_while(|path| path.starts_with(&base)) {
            fs::set_permissions(ancestor, fs::Permissions::from_mode(0o700))
                .expect("runtime fixture directories should be private");
        }
        let runtime_path = root.join("podman");
        fs::write(&runtime_path, b"not executed").expect("runtime fixture should be created");
        fs::set_permissions(&runtime_path, fs::Permissions::from_mode(0o755))
            .expect("runtime fixture should be executable");

        let mut spec = safe_spec();
        spec.command = vec!["x".repeat(200); 16];
        let report = probe_oci_runtime(&runtime_path);
        assert!(
            report.executable_present,
            "runtime fixture should pass preflight: {:?}",
            report.blocked_by
        );
        let error = build_rootless_argv_for_path(&runtime_path, &spec)
            .expect_err("the explicit runtime path should exceed the final argv bound");
        assert!(
            error.contains("argv"),
            "unexpected rejection reason: {error}"
        );
        fs::remove_dir_all(root).expect("runtime fixture should be removed");
    }

    #[cfg(unix)]
    #[test]
    fn explicit_runtime_path_builder_preserves_path_binding_without_execution() {
        use std::os::unix::fs::PermissionsExt;
        let root =
            std::env::temp_dir().join(format!("screentra-oci-runtime-{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&root).expect("runtime fixture directory should be created");
        fs::set_permissions(&root, fs::Permissions::from_mode(0o700))
            .expect("runtime fixture directory should be private");
        let runtime_path = root.join("podman");
        fs::write(&runtime_path, b"not executed").expect("runtime fixture should be created");
        let mut permissions = fs::metadata(&runtime_path)
            .expect("runtime fixture metadata should be readable")
            .permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&runtime_path, permissions)
            .expect("runtime fixture should be executable");

        let args = build_rootless_argv_for_path(&runtime_path, &safe_spec())
            .expect("explicit runtime path should build argv");
        assert_eq!(
            args.first().map(String::as_str),
            Some(runtime_path.to_str().expect("runtime path should be UTF-8"))
        );
        assert!(args.iter().any(|arg| arg == "--pull=never"));
        assert!(args.iter().any(|arg| arg == "registry.example/weather@sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
        assert!(!root.join("started").exists());
        fs::remove_dir_all(root).expect("runtime fixture should be removed");
    }

    #[test]
    fn container_names_remain_bounded_and_activation_distinct() {
        let mut first = safe_spec();
        first.activation_instance =
            "activation-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa".to_string();
        let mut second = first.clone();
        second.activation_instance = "activation-bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb".to_string();

        let first_name = container_name(&first);
        let second_name = container_name(&second);
        assert_ne!(first_name, second_name);
        assert!(first_name.len() <= 63);
        assert!(second_name.len() <= 63);
    }

    #[test]
    fn approved_record_binding_still_respects_disabled_execution_gate() {
        let record = TrustedServiceRuntimeRecord {
            record_version: 1,
            addon_id: "example.weather".to_string(),
            addon_version: "1.0.0".to_string(),
            image: "registry.example/weather".to_string(),
            image_digest: format!("sha256:{}", "a".repeat(64)),
            image_signature_verified: true,
            resource_policy_verified: true,
            network_boundary_verified: true,
            readiness_verified: true,
            credential_broker_verified: true,
            database_boundary_verified: true,
            controlled_gateway_verified: true,
            audit_verified: true,
            image_transport_verified: true,
            lifecycle_rollback_verified: true,
            cleanup_verified: true,
            dedicated_host_verified: true,
            capabilities: vec!["storage".to_string()],
            storage_namespace: "example.weather".to_string(),
            api_namespace: "example.weather".to_string(),
            launch_profile: crate::addons::TrustedServiceLaunchProfile {
                command: vec!["/service".to_string()],
                gateway_socket_path: crate::trusted_service_gateway::GATEWAY_SOCKET_PATH
                    .to_string(),
                rootless: true,
                non_root: true,
                network_disabled: true,
                read_only_rootfs: true,
                no_new_privileges: true,
                drop_all_capabilities: true,
                seccomp_default: true,
                memory_bytes: 256 * 1024 * 1024,
                cpu_millis: 500,
                pids: 64,
                writable_bytes: 16 * 1024 * 1024,
            },
            activation_instance: "activation-1".to_string(),
            state: "approved".to_string(),
            approved_by: Some("admin".to_string()),
            approved_at: Some("2026-10-15T00:00:00Z".to_string()),
            updated_at: "2026-10-15T00:00:00Z".to_string(),
            execution_enabled: false,
            gates: Vec::new(),
            last_error: None,
        };
        validate_oci_approval_metadata(&record).expect("approval metadata should validate");
        assert!(launch_profile_matches(&safe_spec(), &record.launch_profile));
        let mut mismatched_spec = safe_spec();
        mismatched_spec.resources.memory_bytes += 1;
        assert!(!launch_profile_matches(
            &mismatched_spec,
            &record.launch_profile
        ));
        let mut invalid = record.clone();
        invalid.approved_by = Some(String::new());
        assert!(validate_oci_approval_metadata(&invalid).is_err());
        assert!(validate_oci_launch_spec_against_record(&safe_spec(), &record).is_err());
    }
    #[test]
    fn missing_oci_runtime_is_blocked_without_fallback() {
        let report = probe_oci_runtime(Path::new("/definitely/missing/screentra-oci-runtime"));
        assert!(!report.executable_present);
        assert!(!report.can_start);
        assert!(report
            .blocked_by
            .iter()
            .any(|reason| reason == "runtime executable unavailable"));

        let relative = probe_oci_runtime(Path::new("podman"));
        assert!(!relative.executable_present);
        assert!(relative
            .blocked_by
            .iter()
            .any(|reason| reason == "runtime path must be absolute"));
    }

    #[cfg(unix)]
    #[test]
    fn runtime_path_identity_changes_after_replacement() {
        let root = std::env::temp_dir().join(format!("screentra-oci-identity-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let executable = root.join("podman");
        fs::write(&executable, b"first").unwrap();
        let first = super::runtime_path_identity(&executable).expect("first identity");
        fs::rename(&executable, root.join("podman.old")).unwrap();
        fs::write(&executable, b"second").unwrap();
        let second = super::runtime_path_identity(&executable).expect("second identity");
        assert_ne!(first, second);
        fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn runtime_probe_rejects_group_or_other_writable_runtime_files() {
        use std::os::unix::fs::PermissionsExt;

        let root = std::env::temp_dir().join(format!("screentra-oci-permissions-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        let executable = root.join("podman");
        fs::write(&executable, b"not executed").unwrap();
        fs::set_permissions(&executable, fs::Permissions::from_mode(0o775)).unwrap();

        let report = probe_oci_runtime(&executable);
        assert!(!report.executable_present);
        assert!(report
            .blocked_by
            .iter()
            .any(|reason| reason == "runtime path is writable by group or others"));
        fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn runtime_probe_rejects_group_or_other_writable_ancestor_directories() {
        use std::os::unix::fs::PermissionsExt;

        let root = std::env::temp_dir().join(format!("screentra-oci-ancestor-permissions-{}", Uuid::new_v4()));
        fs::create_dir_all(&root).unwrap();
        fs::set_permissions(&root, fs::Permissions::from_mode(0o775)).unwrap();
        let executable = root.join("podman");
        fs::write(&executable, b"not executed").unwrap();
        fs::set_permissions(&executable, fs::Permissions::from_mode(0o755)).unwrap();

        let report = probe_oci_runtime(&executable);
        assert!(!report.executable_present);
        assert!(report
            .blocked_by
            .iter()
            .any(|reason| reason == "runtime path is writable by group or others"));
        fs::remove_dir_all(root).unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn runtime_probe_rejects_symlinked_parent_paths() {
        use std::os::unix::fs::{symlink, PermissionsExt};

        let root = std::env::temp_dir().join(format!("screentra-oci-probe-{}", Uuid::new_v4()));
        let real_dir = root.join("real");
        let symlink_dir = root.join("link");
        let executable = real_dir.join("podman");
        fs::create_dir_all(&real_dir).expect("temporary runtime directory should be created");
        fs::write(&executable, b"not executed").expect("temporary runtime should be created");
        fs::set_permissions(&executable, fs::Permissions::from_mode(0o755))
            .expect("temporary runtime should be executable");
        symlink(&real_dir, &symlink_dir).expect("runtime parent symlink should be created");

        let report = probe_oci_runtime(&symlink_dir.join("podman"));
        assert!(!report.executable_present);
        assert!(!report.can_start);
        assert!(report
            .blocked_by
            .iter()
            .any(|reason| reason == "runtime path contains a symlink"));
        fs::remove_dir_all(root).expect("temporary runtime fixture should be removed");
    }
}
