#!/usr/bin/env bash
set -euo pipefail
DEST="${SCREENTRA_CAST_SERVER_DIR:-/home/board/server}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$ROOT/payload"
if [ "$(id -u)" -ne 0 ]; then
    echo "Run as root or with sudo." >&2
    exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
    command -v apt-get >/dev/null 2>&1 || { echo "FFmpeg is required, but apt-get is unavailable." >&2; exit 1; }
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq ffmpeg
fi
[ -d "$PAYLOAD" ] || { echo "Bundle payload missing: $PAYLOAD" >&2; exit 1; }
install -d -m 0755 "$DEST"
if [ -f "$PAYLOAD/screentra-cast-server" ]; then
    install -m 0755 "$PAYLOAD/screentra-cast-server" "$DEST/screentra-cast-server"
fi
if [ -d "$PAYLOAD/static" ]; then
    install -d -m 0755 "$DEST/static"
    cp -a "$PAYLOAD/static/." "$DEST/static/"
fi
printf '%s\n' "Installed server bundle files under $DEST. Existing database, certificates, uploads, backups, and environment files were preserved."
printf '%s\n' "Restart the configured screentra-cast-server.service after reviewing the installed files."
