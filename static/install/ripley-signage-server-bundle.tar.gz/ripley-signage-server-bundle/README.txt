State-free Screentra Cast server bundle. Run ./install-server.sh as root. Database, certificates, uploads, backups, and environment files are excluded and preserved.
