use crate::db::Database;
use crate::models::Backup;
use crate::safe_archive;
use crate::version::configured_service;
use axum::{
    extract::{FromRef, Multipart, Path, Query, State},
    http::{Response, StatusCode},
    response::Json as AxumJson,
};
use chrono::Utc;
use std::fs;
use std::io::{BufRead, BufReader};
use std::path::{Path as StdPath, PathBuf};
use std::process::Stdio;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::process::Command;
use uuid::Uuid;

const MAX_BACKUP_UPLOAD_BYTES: u64 = 1 << 30;

#[derive(Clone)]
pub enum BackupMetadataRepository {
    Sqlite(std::sync::Arc<Database>),
    Postgres(std::sync::Arc<crate::postgres::PostgresStore>),
}

pub type AppState = BackupMetadataRepository;

impl FromRef<crate::api::AppState> for BackupMetadataRepository {
    fn from_ref(state: &crate::api::AppState) -> Self {
        Self::Sqlite(std::sync::Arc::clone(state))
    }
}

impl BackupMetadataRepository {
    async fn list_backups(&self) -> Result<Vec<Backup>, String> {
        match self {
            Self::Sqlite(db) => db.list_backups(),
            Self::Postgres(store) => store.list_backups().await,
        }
    }

    async fn insert_backup(&self, backup: &Backup) -> Result<(), String> {
        match self {
            Self::Sqlite(db) => db.insert_backup(backup),
            Self::Postgres(store) => store.insert_backup(backup).await,
        }
    }

    async fn get_backup_file_path(&self, id: &str) -> Result<String, String> {
        match self {
            Self::Sqlite(db) => db.get_backup_file_path(id),
            Self::Postgres(store) => store.get_backup_file_path(id).await,
        }
    }

    async fn delete_backup(&self, id: &str) -> Result<u64, String> {
        match self {
            Self::Sqlite(db) => db.delete_backup(id),
            Self::Postgres(store) => store.delete_backup(id).await,
        }
    }
}

fn postgres_tool_environment_from_url(
    database_url: &str,
) -> Result<Vec<(String, String)>, String> {
    let parsed = url::Url::parse(database_url).map_err(|_| "Invalid PostgreSQL database URL".to_string())?;
    if parsed.scheme() != "postgres" && parsed.scheme() != "postgresql" {
        return Err("PostgreSQL database URL is required".to_string());
    }
    let host = parsed
        .host_str()
        .filter(|host| !host.is_empty())
        .map(ToOwned::to_owned)
        .or_else(|| {
            parsed
                .query_pairs()
                .find(|(key, value)| key == "host" && !value.is_empty())
                .map(|(_, value)| value.into_owned())
        })
        .ok_or_else(|| "PostgreSQL database URL must include a host".to_string())?;
    let database = parsed
        .path()
        .trim_start_matches('/')
        .split('/')
        .next()
        .filter(|database| !database.is_empty())
        .ok_or_else(|| "PostgreSQL database URL must include a database name".to_string())?;
    let decode = |value: &str| {
        urlencoding::decode(value)
            .map(|decoded| decoded.into_owned())
            .map_err(|_| "Invalid percent-encoding in PostgreSQL database URL".to_string())
    };
    let mut environment = vec![
        ("PGHOST".to_string(), host.to_string()),
        (
            "PGPORT".to_string(),
            parsed.port().unwrap_or(5432).to_string(),
        ),
        ("PGDATABASE".to_string(), decode(database)?),
    ];
    if !parsed.username().is_empty() {
        environment.push(("PGUSER".to_string(), decode(parsed.username())?));
    }
    if let Some(password) = parsed.password() {
        environment.push(("PGPASSWORD".to_string(), decode(password)?));
    }
    Ok(environment)
}

fn validate_postgres_dump_file(path: &StdPath) -> Result<(), String> {
    let file = fs::File::open(path).map_err(|_| "Failed to read PostgreSQL dump".to_string())?;
    let mut reader = BufReader::new(file);
    let mut line = String::new();
    let mut has_dump_header = false;
    loop {
        line.clear();
        let bytes = reader
            .read_line(&mut line)
            .map_err(|_| "Failed to read PostgreSQL dump".to_string())?;
        if bytes == 0 {
            break;
        }
        let trimmed = line.trim_start();
        if trimmed.starts_with("-- PostgreSQL database dump") {
            has_dump_header = true;
        }
        let upper = trimmed.to_ascii_uppercase();
        if trimmed.starts_with("\\connect")
            || trimmed.starts_with("\\!")
            || trimmed.starts_with("\\copy")
            || trimmed.starts_with("CREATE DATABASE")
            || (upper.starts_with("COPY ") && upper.contains(" PROGRAM "))
        {
            return Err("PostgreSQL dump contains an unsafe database or shell command".to_string());
        }
    }
    if !has_dump_header {
        return Err("PostgreSQL dump header is missing".to_string());
    }
    Ok(())
}

const BACKUP_COMMAND_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(10 * 60);

async fn run_bounded_status(
    mut command: Command,
    timeout: std::time::Duration,
) -> Result<std::process::ExitStatus, String> {
    command
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    let mut child = command
        .spawn()
        .map_err(|error| format!("failed to start command: {error}"))?;
    match tokio::time::timeout(timeout, child.wait()).await {
        Ok(Ok(status)) => Ok(status),
        Ok(Err(error)) => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            Err(format!("wait command: {error}"))
        }
        Err(_) => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            Err("command exceeded its timeout".to_string())
        }
    }
}

async fn create_postgres_dump(output_path: &StdPath) -> Result<(), String> {
    let database_url = crate::postgres::configured_database_url()?;
    let environment = postgres_tool_environment_from_url(&database_url)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        std::fs::OpenOptions::new()
            .create(true)
            .write(true)
            .truncate(true)
            .mode(0o600)
            .open(output_path)
            .map_err(|_| "Failed to prepare PostgreSQL dump file".to_string())?;
    }
    let mut command = Command::new("pg_dump");
    command
        .env_clear()
        .env("PATH", "/usr/bin:/bin")
        .args([
            "--format=plain",
            "--clean",
            "--if-exists",
            "--no-owner",
            "--no-password",
            "--file",
        ])
        .arg(output_path)
        .envs(environment);
    let status = run_bounded_status(command, BACKUP_COMMAND_TIMEOUT).await?;
    if !status.success() {
        let _ = fs::remove_file(output_path);
        return Err("PostgreSQL dump failed".to_string());
    }
    let dump_size = fs::metadata(output_path)
        .map_err(|_| "PostgreSQL dump did not produce a file".to_string())?
        .len();
    if dump_size == 0 {
        let _ = fs::remove_file(output_path);
        return Err("PostgreSQL dump was empty".to_string());
    }
    if let Err(error) = validate_postgres_dump_file(output_path) {
        let _ = fs::remove_file(output_path);
        return Err(error);
    }
    Ok(())
}

async fn restore_postgres_dump(input_path: &StdPath) -> Result<(), String> {
    validate_postgres_dump_file(input_path)?;
    let database_url = crate::postgres::configured_database_url()?;
    let environment = postgres_tool_environment_from_url(&database_url)?;
    let mut command = Command::new("psql");
    command
        .env_clear()
        .env("PATH", "/usr/bin:/bin")
        .args([
            "--no-password",
            "--no-psqlrc",
            "--set",
            "ON_ERROR_STOP=1",
            "--single-transaction",
            "--file",
        ])
        .arg(input_path)
        .envs(environment);
    let status = run_bounded_status(command, BACKUP_COMMAND_TIMEOUT).await?;
    if !status.success() {
        return Err("PostgreSQL restore failed".to_string());
    }
    Ok(())
}

pub async fn list_backups(
    State(db): State<AppState>,
) -> Result<AxumJson<Vec<Backup>>, (StatusCode, String)> {
    db.list_backups().await
        .map(AxumJson)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))
}

pub async fn create_backup(
    State(db): State<AppState>,
) -> Result<AxumJson<Backup>, (StatusCode, String)> {
    let id = Uuid::new_v4().to_string();
    let now = Utc::now().to_rfc3339();
    let safe_ts = now.replace(':', "-");
    let name = format!("Backup {}", &now[..16]);

    let data_dir = signage_data_dir();
    let app_root =
        std::env::current_dir().map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
    let backup_dir = checked_backup_dir(true)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;

    let filename = format!("ripley-signage-{}-{}.tar.gz", safe_ts, id);
    let full_path = format!("{}/{}", backup_dir.display(), filename);

    // Archive the installed app plus the runtime data directory. We cd to the
    // PARENT of each root and pass `./<basename>` so the basename appears in
    // archive paths. This lets us use `--exclude` and `--transform` reliably.
    let install_basename = StdPath::new(&app_root)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "install".to_string());
    let install_parent = StdPath::new(&app_root)
        .parent()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| ".".to_string());
    let data_basename = StdPath::new(&data_dir)
        .file_name()
        .map(|n| n.to_string_lossy().to_string())
        .unwrap_or_else(|| "data".to_string());
    let data_parent = StdPath::new(&data_dir)
        .parent()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| ".".to_string());
    let postgres_dump_path = if matches!(&db, BackupMetadataRepository::Postgres(_)) {
        let parent = StdPath::new(&data_dir).parent().ok_or((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ))?;
        let path = parent.join(format!(".screentra-postgres-dump-{id}.sql"));
        create_postgres_dump(&path).await.map_err(|_| {
            (
                StatusCode::INTERNAL_SERVER_ERROR,
                "PostgreSQL backup failed".to_string(),
            )
        })?;
        Some(path)
    } else {
        None
    };

    // Exclude pre-transform paths: `./<install_basename>/target` etc.
    // tar's --exclude matches before --transform runs.
    let mut cmd = Command::new("tar");
    cmd.arg("-czf")
        .arg(&full_path)
        .arg(format!("--exclude=./{}/target", install_basename))
        .arg(format!("--exclude=./{}/.git", install_basename))
        .arg(format!("--exclude=./{}/server-run.log", install_basename))
        .arg(format!("--exclude=./{}/server-run.pid", install_basename))
        .arg(format!("--exclude=./{}/backups", install_basename))
        // screentra-cast-signage-ca.crt inside the install dir is a published
        // copy of the local CA; only the protected certs copy is authoritative.
        .arg(format!(
            "--exclude=./{}/screentra-cast-signage-ca.crt",
            install_basename
        ))
        // Exclude old backups under data/ so each backup doesn't pack the
        // previous tarballs (~750 MB each, would explode size).
        .arg(format!("--exclude=./{}/backups", data_basename))
        // The PostgreSQL-native dump is added separately below.
        .arg(format!("--exclude=./{}/postgresql.sql", data_basename))
        // Transform: `./<install_basename>` -> `./app`, `./<data_basename>` -> `./data`.
        // Without the parent-cd trick above, the basenames don't appear in
        // archive paths and the transforms silently no-op.
        .arg("--transform")
        .arg(format!("s|./{}/|./app/|", install_basename))
        .arg("--transform")
        .arg(format!("s|./{}/|./data/|", data_basename))
        .arg("-C")
        .arg(&install_parent)
        .arg(format!("./{}", install_basename))
        .arg("-C")
        .arg(&data_parent)
        .arg(format!("./{}", data_basename));
    if let Some(path) = &postgres_dump_path {
        let filename = path
            .file_name()
            .and_then(|name| name.to_str())
            .ok_or((
                StatusCode::INTERNAL_SERVER_ERROR,
                "Internal server error".to_string(),
            ))?;
        cmd.arg("--transform")
            .arg(format!("s|./{filename}|./data/postgresql.sql|"))
            .arg("-C")
            .arg(path.parent().unwrap_or_else(|| StdPath::new(".")))
            .arg(format!("./{filename}"));
    }

    let status = run_bounded_status(cmd, BACKUP_COMMAND_TIMEOUT).await;
    if let Some(path) = &postgres_dump_path {
        let _ = fs::remove_file(path);
    }
    let status = status
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;

    if !status.success() {
        log::error!("backup tar creation failed");
        let _ = fs::remove_file(&full_path);
        return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
    }

    if let Err(error) = restrict_backup_file(StdPath::new(&full_path)) {
        log::error!("restrict created backup permissions failed: {error}");
        let _ = fs::remove_file(&full_path);
        return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
    }

    let size = match fs::metadata(&full_path) {
        Ok(metadata) => metadata.len(),
        Err(error) => {
            log::error!("inspect created backup failed: {error}");
            let _ = fs::remove_file(&full_path);
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
    };

    let backup = Backup {
        id: id.clone(),
        name: name.clone(),
        created_at: now.clone(),
        file_path: full_path.clone(),
        size_bytes: size,
    };

    if let Err(error) = db.insert_backup(&backup).await {
        let _ = fs::remove_file(&full_path);
        log::error!("register created backup failed: {error}");
        return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
    }

    Ok(AxumJson(backup))
}

fn restrict_backup_file(path: &StdPath) -> Result<(), String> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let metadata = fs::symlink_metadata(path)
            .map_err(|error| format!("inspect backup permissions: {error}"))?;
        if metadata.file_type().is_symlink() || !metadata.is_file() {
            return Err("backup path is not a regular file".to_string());
        }
        let mut permissions = metadata.permissions();
        permissions.set_mode(0o600);
        fs::set_permissions(path, permissions)
            .map_err(|error| format!("restrict backup permissions: {error}"))?;
    }
    Ok(())
}

fn signage_data_dir() -> String {
    if let Ok(dir) = std::env::var("SIGNAGE_DATA_DIR") {
        return dir;
    }
    let home = std::env::var("HOME").unwrap_or_else(|_| "/home/ripley".to_string());
    format!("{}/.local/share/signage", home)
}

fn checked_backup_dir(create: bool) -> Result<PathBuf, String> {
    let data_dir = PathBuf::from(signage_data_dir());
    let mut current = data_dir.as_path();
    loop {
        match fs::symlink_metadata(current) {
            Ok(metadata) if metadata.file_type().is_symlink() => {
                return Err("Invalid backup data directory".to_string());
            }
            Ok(_) => {}
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
            Err(error) => return Err(format!("inspect backup data directory: {error}")),
        }
        let Some(parent) = current.parent() else {
            break;
        };
        if parent == current {
            break;
        }
        current = parent;
    }
    match fs::symlink_metadata(&data_dir) {
        Ok(metadata) if metadata.file_type().is_symlink() || !metadata.is_dir() => {
            return Err("Invalid backup data directory".to_string());
        }
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound && create => {
            fs::create_dir_all(&data_dir)
                .map_err(|error| format!("create backup data directory: {error}"))?;
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            return Err("Backup data directory is unavailable".to_string());
        }
        Err(error) => return Err(format!("inspect backup data directory: {error}")),
    }
    let backup_dir = data_dir.join("backups");
    match fs::symlink_metadata(&backup_dir) {
        Ok(metadata) if metadata.file_type().is_symlink() || !metadata.is_dir() => {
            Err("Invalid backup storage directory".to_string())
        }
        Ok(_) => Ok(backup_dir),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound && create => {
            fs::create_dir_all(&backup_dir)
                .map_err(|error| format!("create backup storage directory: {error}"))?;
            let metadata = fs::symlink_metadata(&backup_dir)
                .map_err(|error| format!("inspect backup storage directory: {error}"))?;
            if metadata.file_type().is_symlink() || !metadata.is_dir() {
                return Err("Invalid backup storage directory".to_string());
            }
            Ok(backup_dir)
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            Err("Backup storage directory is unavailable".to_string())
        }
        Err(error) => Err(format!("inspect backup storage directory: {error}")),
    }
}

const MAX_BACKUP_ID_BYTES: usize = 128;

fn validate_backup_id(id: &str) -> Result<(), (StatusCode, String)> {
    if id.is_empty()
        || id.len() > MAX_BACKUP_ID_BYTES
        || id.chars().any(|character| character.is_control())
    {
        return Err((StatusCode::BAD_REQUEST, "Invalid backup identifier".to_string()));
    }
    Ok(())
}

fn checked_backup_file(path: &str) -> Result<bool, String> {
    let backup_dir = checked_backup_dir(false)?;
    let candidate = StdPath::new(path);
    if candidate.parent() != Some(backup_dir.as_path()) {
        return Err("Backup file is outside the backup storage directory".to_string());
    }
    match fs::symlink_metadata(candidate) {
        Ok(metadata) if metadata.file_type().is_symlink() || !metadata.is_file() => {
            Err("Invalid backup file".to_string())
        }
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(format!("inspect backup file: {error}")),
    }
}

#[derive(serde::Serialize)]
struct RestoreDryRunReport {
    install_dir: String,
    data_dir: String,
    service_name: String,
    service_kind: &'static str,
    backup_sha256: String,
    tarball_top_level_entries: Vec<String>,
    contains_core_database: bool,
    contains_postgresql_dump: bool,
    contains_trusted_service_staging: bool,
    would_extract_to_install: bool,
    would_extract_to_data: bool,
    would_restart_service: bool,
    warnings: Vec<String>,
}

#[derive(serde::Serialize)]
struct RestoreResult {
    status: &'static str,
    install_dir: String,
    data_dir: String,
    service_name: String,
    service_kind: &'static str,
    sha256_pre: String,
    sha256_post: String,
    duration_ms: u64,
    pre_restore_dir: Option<String>,
    pre_restore_database_dump: Option<String>,
    restored_at: String,
}

fn tar_top_level_entries(tarball: &str) -> Result<Vec<String>, String> {
    safe_archive::inspect_tar_gz(StdPath::new(tarball))
}

fn validate_postgres_archive(path: &StdPath) -> Result<(), String> {
    let contains_dump = safe_archive::archive_contains_path(path, StdPath::new("data/postgresql.sql"))?;
    if !contains_dump {
        return Err("backup archive does not contain data/postgresql.sql".to_string());
    }
    let extraction_root = std::env::temp_dir().join(format!("screentra-pg-upload-{}", Uuid::new_v4()));
    let result = (|| {
        safe_archive::extract_tar_gz(path, &extraction_root, 0)?;
        validate_postgres_dump_file(&extraction_root.join("data/postgresql.sql"))
    })();
    let _ = fs::remove_dir_all(&extraction_root);
    result
}

fn cleanup_postgres_rollback_dump(path: Option<&StdPath>) {
    if let Some(path) = path {
        let _ = fs::remove_file(path);
    }
}

async fn sha256_file(path: &str) -> Result<String, String> {
    const MAX_HASH_COMMAND_OUTPUT_BYTES: usize = 4096;
    let mut child = Command::new("sha256sum")
        .arg(path)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("sha256sum: {}", e))?;
    let stdout = match child.stdout.take() {
        Some(stdout) => stdout,
        None => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            return Err("sha256sum stdout unavailable".to_string());
        }
    };
    let mut bytes = Vec::new();
    let read_result = tokio::time::timeout(
        std::time::Duration::from_secs(30),
        stdout
            .take((MAX_HASH_COMMAND_OUTPUT_BYTES + 1) as u64)
            .read_to_end(&mut bytes),
    )
    .await;
    match read_result {
        Ok(Ok(_)) => {}
        Ok(Err(error)) => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            return Err(format!("sha256sum output: {}", error));
        }
        Err(_) => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            return Err("sha256sum output timed out".to_string());
        }
    }
    if bytes.len() > MAX_HASH_COMMAND_OUTPUT_BYTES {
        let _ = child.kill().await;
        let _ = child.wait().await;
        return Err("sha256sum output exceeds its bound".to_string());
    }
    let status = match child.wait().await {
        Ok(status) => status,
        Err(error) => {
            let _ = child.kill().await;
            let _ = child.wait().await;
            return Err(format!("sha256sum wait: {}", error));
        }
    };
    if !status.success() {
        return Err("sha256sum failed".to_string());
    }
    let s = String::from_utf8_lossy(&bytes);
    Ok(s.split_whitespace().next().unwrap_or("").to_string())
}

fn configured_service_target_allowed(service: &str, kind: &str) -> bool {
    matches!(
        (service, kind),
        ("screentra-cast-server.service", "system")
            | ("signage.service", "system")
            | ("screentra-cast-server.service", "user")
            | ("signage-server.service", "user")
    )
}

async fn systemctl_action(action: &str, service: &str, kind: &str) -> Result<(), String> {
    if !configured_service_target_allowed(service, kind) {
        log::warn!("refusing systemctl action for unapproved service target: kind={kind}");
        return Err("service action denied".to_string());
    }
    let mut cmd = if kind == "user" {
        let mut c = Command::new("systemctl");
        c.arg("--user");
        c.arg(action);
        c.arg(service);
        c
    } else {
        let mut c = Command::new("sudo");
        c.arg("-n"); // non-interactive — fail loud if password is needed
        c.arg("systemctl");
        c.arg(action);
        c.arg(service);
        c
    };
    cmd.stdin(std::process::Stdio::null());
    cmd.stdout(Stdio::null());
    cmd.stderr(Stdio::null());
    let status = run_bounded_status(cmd, std::time::Duration::from_secs(30)).await?;
    if !status.success() {
        eprintln!("systemctl action failed: action={action} service={service}");
        return Err("service action failed".to_string());
    }
    Ok(())
}

pub async fn restore_backup(
    State(db): State<AppState>,
    Path(id): Path<String>,
    Query(params): Query<std::collections::HashMap<String, String>>,
) -> Result<axum::http::Response<axum::body::Body>, (StatusCode, String)> {
    validate_backup_id(&id)?;
    use axum::body::Body;
    use axum::http::{header, StatusCode as SC};
    let backup_file_path = db
        .get_backup_file_path(&id)
        .await
        .map_err(|_| {
            (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string())
        })?;

    match checked_backup_file(&backup_file_path) {
        Ok(true) => {}
        Ok(false) => return Err((StatusCode::NOT_FOUND, "Backup not found".to_string())),
        Err(error) => {
            log::warn!("backup path validation failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
    }

    // Detect service + dirs (same helpers create_backup uses).
    let install_dir = std::env::current_dir()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|_| "/opt/digital-signage".to_string());
    let data_dir = signage_data_dir();
    let postgres_backend = matches!(&db, BackupMetadataRepository::Postgres(_));
    let (service_name, service_kind) = configured_service();

    let top = match tar_top_level_entries(&backup_file_path) {
        Ok(top) => top,
        Err(error) => {
            log::warn!("backup archive inspection failed: {error}");
            return Err((StatusCode::BAD_REQUEST, "Invalid backup archive".to_string()));
        }
    };
    let sha = sha256_file(&backup_file_path)
        .await
        .map_err(|_| {
            (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string())
        })?;

    let contains_core_database = safe_archive::archive_contains_path(
        StdPath::new(&backup_file_path),
        StdPath::new("data/signage.db"),
    )
    .map_err(|error| {
        log::warn!("backup archive inspection failed: {error}");
        (StatusCode::BAD_REQUEST, "Invalid backup archive".to_string())
    })?;
    let contains_postgresql_dump = safe_archive::archive_contains_path(
        StdPath::new(&backup_file_path),
        StdPath::new("data/postgresql.sql"),
    )
    .map_err(|error| {
        log::warn!("backup archive inspection failed: {error}");
        (StatusCode::BAD_REQUEST, "Invalid backup archive".to_string())
    })?;
    let contains_trusted_service_staging = safe_archive::archive_contains_path_prefix(
        StdPath::new(&backup_file_path),
        StdPath::new("data/trusted-services"),
    )
    .map_err(|error| {
        log::warn!("backup archive inspection failed: {error}");
        (StatusCode::BAD_REQUEST, "Invalid backup archive".to_string())
    })?;

    let mut warnings: Vec<String> = Vec::new();
    let would_app = top.iter().any(|e| e == "app");
    let would_data = top.iter().any(|e| e == "data");
    if !would_app {
        warnings
            .push("tarball has no `app/` top-level — install dir will not be restored".to_string());
    }
    if !would_data {
        warnings
            .push("tarball has no `data/` top-level — data dir will not be restored".to_string());
    }
    if !contains_core_database {
        warnings.push(
            "tarball has no `data/signage.db` — addon storage cannot be restored".to_string(),
        );
    }
    if postgres_backend && !contains_postgresql_dump {
        warnings.push(
            "tarball has no `data/postgresql.sql` — PostgreSQL data cannot be restored".to_string(),
        );
    }
    if !contains_trusted_service_staging {
        warnings.push(
            "tarball has no `data/trusted-services/` — staged trusted-service metadata will not be restored".to_string(),
        );
    }

    let report = RestoreDryRunReport {
        install_dir: install_dir.clone(),
        data_dir: data_dir.clone(),
        service_name: service_name.clone(),
        service_kind,
        backup_sha256: sha.clone(),
        tarball_top_level_entries: top,
        contains_core_database,
        contains_postgresql_dump,
        contains_trusted_service_staging,
        would_extract_to_install: would_app,
        would_extract_to_data: would_data,
        would_restart_service: true,
        warnings: warnings.clone(),
    };

    // Dry-run gate. Without `?confirm=true` OR with `?dry_run=true`,
    // return the report (200) without touching disk.
    let want_dry_run = params.get("dry_run").map(|v| v == "true").unwrap_or(false);
    let confirmed = params.get("confirm").map(|v| v == "true").unwrap_or(false);
    if !confirmed || want_dry_run {
        let body = serde_json::json!({
            "status": "dry_run",
            "report": report,
        });
        let resp = Response::builder()
            .status(SC::OK)
            .header(header::CONTENT_TYPE, "application/json")
            .body(Body::from(body.to_string()))
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
        return Ok(resp);
    }

    // === actual restore ===
    let started = std::time::Instant::now();
    let restored_at = Utc::now().to_rfc3339();

    // Stage the tarball OUTSIDE the install/data dirs but on the install
    // directory's filesystem. The final directory swaps use rename(2), so
    // choosing /var/tmp or $TMPDIR could cause EXDEV on split filesystems.
    let ts = chrono::Utc::now().timestamp_millis();
    let staging_parent = StdPath::new(&install_dir)
        .parent()
        .map(|path| path.to_string_lossy().to_string())
        .filter(|path| !path.is_empty())
        .ok_or((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Failed to determine staging parent".to_string(),
        ))?;
    let staging_root = format!(
        "{}/ripley-restore-{}-{}",
        staging_parent,
        std::process::id(),
        ts
    );
    if let Err(e) = fs::create_dir_all(&staging_root) {
        log::error!("create backup restore staging failed: {e}");
        return Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ));
    }

    let extract_result = safe_archive::extract_tar_gz(
        StdPath::new(&backup_file_path),
        StdPath::new(&staging_root),
        0,
    );
    if let Err(error) = extract_result {
        log::warn!("backup restore archive rejected: {error}");
        let _ = fs::remove_dir_all(&staging_root);
        return Err((
            StatusCode::BAD_REQUEST,
            "Invalid backup archive".to_string(),
        ));
    }

    let postgres_dump_path = if postgres_backend {
        let path = StdPath::new(&staging_root).join("data/postgresql.sql");
        if !path.is_file() {
            let _ = fs::remove_dir_all(&staging_root);
            return Err((
                StatusCode::BAD_REQUEST,
                "PostgreSQL backup is missing data/postgresql.sql".to_string(),
            ));
        }
        if let Err(error) = validate_postgres_dump_file(&path) {
            log::warn!("PostgreSQL backup dump rejected: {error}");
            let _ = fs::remove_dir_all(&staging_root);
            return Err((StatusCode::BAD_REQUEST, "Invalid PostgreSQL dump".to_string()));
        }
        Some(path)
    } else {
        None
    };
    let postgres_rollback_path = if postgres_backend {
        let path = StdPath::new(&staging_parent)
            .join(format!("screentra-postgres-rollback-{ts}.sql"));
        if let Err(error) = create_postgres_dump(&path).await {
            log::error!("PostgreSQL rollback dump failed: {error}");
            let _ = fs::remove_dir_all(&staging_root);
            let _ = fs::remove_file(&path);
            return Err((
                StatusCode::INTERNAL_SERVER_ERROR,
                "PostgreSQL rollback dump failed".to_string(),
            ));
        }
        Some(path)
    } else {
        None
    };

    // Move existing install/data aside so the swap is atomic.
    let pre_restore_app = format!("{}.pre-restore-{}", install_dir, ts);
    let pre_restore_data = format!("{}.pre-restore-{}", data_dir, ts);
    if let Err(e) = fs::rename(&install_dir, &pre_restore_app) {
        log::error!("backup restore install rename failed: {e}");
        cleanup_postgres_rollback_dump(postgres_rollback_path.as_deref());
        let _ = fs::remove_dir_all(&staging_root);
        return Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ));
    }
    if let Err(e) = fs::rename(&data_dir, &pre_restore_data) {
        log::error!("backup restore data rename failed: {e}");
        cleanup_postgres_rollback_dump(postgres_rollback_path.as_deref());
        // Roll back the install rename.
        let _ = fs::rename(&pre_restore_app, &install_dir);
        let _ = fs::remove_dir_all(&staging_root);
        return Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ));
    }

    if let Err(e) = fs::rename(format!("{}/app", staging_root), &install_dir) {
        log::error!("backup restore app placement failed: {e}");
        cleanup_postgres_rollback_dump(postgres_rollback_path.as_deref());
        // Rollback both renames + remove staging.
        let _ = fs::rename(&pre_restore_app, &install_dir);
        let _ = fs::rename(&pre_restore_data, &data_dir);
        let _ = fs::remove_dir_all(&staging_root);
        return Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ));
    }
    if let Err(e) = fs::rename(format!("{}/data", staging_root), &data_dir) {
        log::error!("backup restore data placement failed: {e}");
        cleanup_postgres_rollback_dump(postgres_rollback_path.as_deref());
        // Rollback app placement, install rename, data rename.
        let _ = fs::remove_dir_all(&install_dir);
        let _ = fs::rename(&pre_restore_app, &install_dir);
        let _ = fs::rename(&pre_restore_data, &data_dir);
        let _ = fs::remove_dir_all(&staging_root);
        return Err((
            StatusCode::INTERNAL_SERVER_ERROR,
            "Internal server error".to_string(),
        ));
    }

    if let Some(rollback_path) = postgres_rollback_path.as_ref() {
        if let Some(dump_path) = postgres_dump_path.as_ref() {
            let live_dump_path = StdPath::new(&data_dir).join(
                dump_path
                    .file_name()
                    .unwrap_or_else(|| std::ffi::OsStr::new("postgresql.sql")),
            );
            if let Err(error) = restore_postgres_dump(&live_dump_path).await {
                log::error!("PostgreSQL restore failed after filesystem swap: {error}");
                let _ = fs::remove_dir_all(&install_dir);
                let _ = fs::remove_dir_all(&data_dir);
                let _ = fs::rename(&pre_restore_app, &install_dir);
                let _ = fs::rename(&pre_restore_data, &data_dir);
                let rollback_error = restore_postgres_dump(rollback_path).await.err();
                let _ = fs::remove_file(rollback_path);
                let _ = fs::remove_dir_all(&staging_root);
                if rollback_error.is_some() {
                    log::error!("PostgreSQL rollback restore failed");
                }
                return Err((
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "PostgreSQL restore failed; filesystem rollback was attempted".to_string(),
                ));
            }
            if let Err(error) = fs::remove_file(&live_dump_path) {
                log::warn!("could not remove restored PostgreSQL dump: {error}");
            }
        }
    }

    if let Some(rollback_path) = postgres_rollback_path.as_ref() {
        if let Err(error) = fs::remove_file(rollback_path) {
            warnings.push(format!("could not remove PostgreSQL rollback dump: {error}"));
        }
    }

    if postgres_backend {
        let restored_backup = Backup {
            id: id.clone(),
            name: format!("Restored backup {}", &restored_at[..16]),
            created_at: restored_at.clone(),
            file_path: backup_file_path.clone(),
            size_bytes: fs::metadata(&backup_file_path)
                .map(|metadata| metadata.len())
                .unwrap_or_default(),
        };
        if let Err(error) = db.insert_backup(&restored_backup).await {
            warnings.push(format!("backup metadata re-registration failed: {error}"));
        }
    }

    // Staging dir should now be empty (we moved app/ and data/ out).
    let _ = fs::remove_dir_all(&staging_root);

    // Restart the service. Use --user or sudo -n; never hang on a TTY.
    // This is best-effort: a running binary under the dev box doesn't have
    // a systemd service, so systemctl will fail. We log the warning and
    // continue — the data on disk is already swapped.
    if let Err(e) = systemctl_action("restart", &service_name, service_kind).await {
        warnings.push(format!("service restart failed: {}", e));
    }

    let post_sha = if postgres_backend {
        String::new()
    } else {
        sha256_file(&format!("{}/signage.db", data_dir))
            .await
            .unwrap_or_default()
    };

    let result = RestoreResult {
        status: "restored",
        install_dir,
        data_dir,
        service_name,
        service_kind,
        sha256_pre: sha,
        sha256_post: post_sha,
        duration_ms: started.elapsed().as_millis() as u64,
        pre_restore_dir: Some(pre_restore_app),
        pre_restore_database_dump: None,
        restored_at,
    };

    let body = serde_json::json!({
        "status": "restored",
        "result": result,
        "warnings": warnings,
    });
    let resp = Response::builder()
        .status(SC::OK)
        .header(header::CONTENT_TYPE, "application/json")
        .body(Body::from(body.to_string()))
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
    Ok(resp)
}

pub async fn delete_backup(
    State(db): State<AppState>,
    Path(id): Path<String>,
) -> Result<axum::http::StatusCode, (StatusCode, String)> {
    validate_backup_id(&id)?;
    let file_path = db
        .get_backup_file_path(&id)
        .await
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;

    match checked_backup_file(&file_path) {
        Ok(true) | Ok(false) => {}
        Err(error) => {
            log::warn!("backup path validation failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
    }

    // Delete the file if it exists. Preserve the database record when the
    // filesystem refuses deletion so the operator can retry safely.
    if let Err(error) = fs::remove_file(&file_path) {
        if error.kind() != std::io::ErrorKind::NotFound {
            log::error!("delete backup file failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
    }

    // Always delete the database record once the file is gone or already absent.
    db.delete_backup(&id)
        .await
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
    Ok(axum::http::StatusCode::NO_CONTENT)
}

pub async fn upload_backup(
    State(db): State<AppState>,
    mut multipart: Multipart,
) -> Result<axum::http::StatusCode, (StatusCode, String)> {
    let postgres_backend = matches!(&db, BackupMetadataRepository::Postgres(_));
    let backup_dir = checked_backup_dir(true)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;

    if let Ok(Some(field)) = multipart.next_field().await {
        let filename = field.file_name().unwrap_or("uploaded.tar.gz").to_string();
        // Strip any path separators from the filename.
        let safe_name = filename
            .rsplit('/')
            .next()
            .unwrap_or(&filename)
            .rsplit('\\')
            .next()
            .unwrap_or(&filename)
            .to_string();
        if safe_name.is_empty()
            || safe_name.contains("..")
            || safe_name.chars().any(|character| character.is_ascii_control() || character == '"')
        {
            return Err((StatusCode::BAD_REQUEST, "Invalid backup filename".to_string()));
        }
        let storage_name = format!("{}-{}", Uuid::new_v4(), safe_name);
        let full_path = format!("{}/{}", backup_dir.display(), storage_name);

        // Stream to a private temporary file rather than buffering an entire
        // multipart backup in memory. The limit is enforced while reading.
        let probe_path = format!("{}/.upload-{}", backup_dir.display(), Uuid::new_v4());
        let mut probe_file = tokio::fs::File::create(&probe_path)
            .await
            .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
        let mut size = 0_u64;
        let mut field = field;
        loop {
            let chunk = match field.chunk().await {
                Ok(Some(chunk)) => chunk,
                Ok(None) => break,
                Err(error) => {
                    drop(probe_file);
                    let _ = tokio::fs::remove_file(&probe_path).await;
                    log::warn!("backup multipart read failed: {error}");
                    return Err((StatusCode::BAD_REQUEST, "Invalid multipart upload".to_string()));
                }
            };
            size = size.saturating_add(chunk.len() as u64);
            if size > MAX_BACKUP_UPLOAD_BYTES {
                drop(probe_file);
                let _ = tokio::fs::remove_file(&probe_path).await;
                return Err((StatusCode::PAYLOAD_TOO_LARGE, "Backup upload is too large".to_string()));
            }
            if let Err(error) = probe_file.write_all(&chunk).await {
                drop(probe_file);
                let _ = tokio::fs::remove_file(&probe_path).await;
                log::error!("write backup upload probe failed: {error}");
                return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
            }
        }
        if let Err(error) = probe_file.flush().await {
            drop(probe_file);
            let _ = tokio::fs::remove_file(&probe_path).await;
            log::error!("flush backup upload probe failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
        drop(probe_file);
        if let Err(error) = restrict_backup_file(StdPath::new(&probe_path)) {
            log::error!("restrict uploaded backup permissions failed: {error}");
            let _ = fs::remove_file(&probe_path);
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }

        // Verify it parses as a tarball with `app/` and/or `data/` at top
        // before saving. Reject anything else.
        let top = match tar_top_level_entries(&probe_path) {
            Ok(t) => t,
            Err(error) => {
                let _ = fs::remove_file(&probe_path);
                log::warn!("uploaded backup is not a valid tarball: {error}");
                return Err((StatusCode::BAD_REQUEST, "Uploaded file is not a valid backup".to_string()));
            }
        };
        if !top.iter().any(|e| e == "app") && !top.iter().any(|e| e == "data") {
            let _ = fs::remove_file(&probe_path);
            return Err((
                StatusCode::BAD_REQUEST,
                "Uploaded backup has no app or data payload".to_string(),
            ));
        }

        if postgres_backend {
            validate_postgres_archive(StdPath::new(&probe_path)).map_err(|error| {
                let _ = fs::remove_file(&probe_path);
                log::warn!("uploaded PostgreSQL backup failed validation: {error}");
                (
                    StatusCode::BAD_REQUEST,
                    "Uploaded PostgreSQL backup is missing or invalid".to_string(),
                )
            })?;
        }

        if let Err(error) = fs::rename(&probe_path, &full_path) {
            let _ = fs::remove_file(&probe_path);
            log::error!("store uploaded backup failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }

        // Register in DB so the operator can pick this backup for restore
        // via PUT /api/backups/{id}?confirm=true. NO auto-restore.
        let id = Uuid::new_v4().to_string();
        let now = Utc::now().to_rfc3339();
        let size = size as i64;
        let name = format!("Uploaded {}", &now[..16]);
        let _backup = Backup {
            id: id.clone(),
            name: name.clone(),
            created_at: now.clone(),
            file_path: full_path.clone(),
            size_bytes: size as u64,
        };
        if let Err(error) = db.insert_backup(&_backup).await {
            let _ = fs::remove_file(&full_path);
            log::error!("register uploaded backup failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }

        return Ok(axum::http::StatusCode::CREATED);
    }

    Err((StatusCode::BAD_REQUEST, "No file uploaded".to_string()))
}

pub async fn download_backup(
    Path(id): Path<String>,
    State(db): State<AppState>,
) -> Result<Response<axum::body::Body>, (StatusCode, String)> {
    validate_backup_id(&id)?;
    let file_path = db
        .get_backup_file_path(&id)
        .await
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;

    match checked_backup_file(&file_path) {
        Ok(true) => {}
        Ok(false) => return Err((StatusCode::NOT_FOUND, "Backup not found".to_string())),
        Err(error) => {
            log::warn!("backup path validation failed: {error}");
            return Err((StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()));
        }
    }

    let path = StdPath::new(&file_path);
    let filename = path
        .file_name()
        .and_then(|name| name.to_str())
        .ok_or((StatusCode::NOT_FOUND, "Backup not found".to_string()))?;
    let header_filename: String = filename
        .chars()
        .map(|character| {
            if character.is_ascii_control() || character == '"' || character == '\\' {
                '_'
            } else {
                character
            }
        })
        .collect();
    let metadata = fs::metadata(path)
        .map_err(|_| (StatusCode::NOT_FOUND, "Backup not found".to_string()))?;

    let file = tokio::fs::File::open(path)
        .await
        .map_err(|_| (StatusCode::NOT_FOUND, "Backup not found".to_string()))?;
    let stream = tokio_util::io::ReaderStream::new(file);

    let body = axum::body::Body::from_stream(stream);

    let response = Response::builder()
        .header("Content-Type", "application/gzip")
        .header(
            "Content-Disposition",
            format!("attachment; filename=\"{}\"", header_filename),
        )
        .header("Content-Length", metadata.len().to_string())
        .body(body)
        .map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, "Internal server error".to_string()))?;
    Ok(response)
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::{
        body::to_bytes,
        http::{Request, StatusCode},
        routing::{post, put},
        Router,
    };
    use flate2::{write::GzEncoder, Compression};
    use std::sync::Mutex;
    #[cfg(unix)]
    use std::os::unix::fs::PermissionsExt;
    use tar::Builder;
    use tower::ServiceExt;

    fn test_root(label: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!(
            "screentra-backup-http-{label}-{}",
            uuid::Uuid::new_v4()
        ))
    }

    fn append_test_file(builder: &mut Builder<GzEncoder<std::fs::File>>, path: &str, data: &[u8]) {
        let mut header = tar::Header::new_gnu();
        header.set_size(data.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        builder.append_data(&mut header, path, data).unwrap();
    }

    #[test]
    fn configured_service_target_allowlist_is_exact() {
        assert!(configured_service_target_allowed("screentra-cast-server.service", "system"));
        assert!(configured_service_target_allowed("signage.service", "system"));
        assert!(configured_service_target_allowed("screentra-cast-server.service", "user"));
        assert!(configured_service_target_allowed("signage-server.service", "user"));
        assert!(!configured_service_target_allowed("../../tmp/evil.service", "system"));
        assert!(!configured_service_target_allowed("signage.service", "user"));
        assert!(!configured_service_target_allowed("signage.service", "SYSTEM"));
    }

    #[test]
    fn backup_identifiers_are_bounded_and_control_free() {
        assert!(validate_backup_id("backup-1").is_ok());
        assert!(validate_backup_id("").is_err());
        assert!(validate_backup_id(&"x".repeat(MAX_BACKUP_ID_BYTES + 1)).is_err());
        assert!(validate_backup_id("backup\n1").is_err());
    }
    #[cfg(unix)]
    #[test]
    fn checked_backup_file_rejects_symlinks_and_outside_paths() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let root = test_root("checked-file");
        let data_dir = root.join("data");
        let backup_dir = data_dir.join("backups");
        std::fs::create_dir_all(&backup_dir).unwrap();
        let inside = backup_dir.join("inside.tar.gz");
        let outside = root.join("outside.tar.gz");
        std::fs::write(&inside, b"backup").unwrap();
        std::fs::write(&outside, b"outside").unwrap();
        std::os::unix::fs::symlink(&outside, backup_dir.join("redirect.tar.gz")).unwrap();

        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        unsafe { std::env::set_var("SIGNAGE_DATA_DIR", &data_dir); }
        assert_eq!(checked_backup_file(inside.to_str().unwrap()), Ok(true));
        assert!(checked_backup_file(outside.to_str().unwrap()).is_err());
        assert!(checked_backup_file(backup_dir.join("redirect.tar.gz").to_str().unwrap()).is_err());
        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn postgres_tool_environment_passes_credentials_via_environment() {
        let environment = postgres_tool_environment_from_url(
            "postgresql://backup%20user:secret%20password@example.test:5544/signage%20db",
        )
        .unwrap();
        assert!(environment.contains(&("PGHOST".to_string(), "example.test".to_string())));
        assert!(environment.contains(&("PGPORT".to_string(), "5544".to_string())));
        assert!(environment.contains(&("PGUSER".to_string(), "backup user".to_string())));
        assert!(environment.contains(&("PGPASSWORD".to_string(), "secret password".to_string())));
        assert!(environment.contains(&("PGDATABASE".to_string(), "signage db".to_string())));
    }

    #[test]
    fn postgres_tool_environment_rejects_non_postgres_or_incomplete_urls() {
        assert!(postgres_tool_environment_from_url("sqlite:///tmp/signage.db").is_err());
        assert!(postgres_tool_environment_from_url("postgresql://user@/signage").is_err());
        assert!(postgres_tool_environment_from_url("postgresql://user@example.test").is_err());
        let socket_environment = postgres_tool_environment_from_url(
            "postgresql:///signage?host=%2Fvar%2Frun%2Fpostgresql",
        )
        .unwrap();
        assert!(socket_environment.contains(&(
            "PGHOST".to_string(),
            "/var/run/postgresql".to_string()
        )));
    }
    #[tokio::test]
    async fn bounded_command_status_kills_timed_out_process() {
        let mut command = Command::new("python3");
        command.args(["-c", "import time; time.sleep(5)"]);
        let error = run_bounded_status(command, std::time::Duration::from_millis(50))
            .await
            .expect_err("timed-out command should be terminated");
        assert!(error.contains("command exceeded its timeout"));
    }

    #[test]
    fn postgres_dump_validator_accepts_pg_dump_header() {
        let path = test_root("postgres-dump-valid");
        std::fs::write(
            &path,
            b"-- PostgreSQL database dump\nSET statement_timeout = 0;\n",
        )
        .unwrap();
        assert!(validate_postgres_dump_file(&path).is_ok());
        std::fs::remove_file(path).unwrap();
    }

    #[test]
    fn postgres_dump_validator_rejects_routing_and_shell_commands() {
        for (label, command) in [
            ("connect", "\\connect other_db\n"),
            ("shell", "\\! id\n"),
            ("create", "CREATE DATABASE other_db;\n"),
            ("copy-program", "COPY users FROM PROGRAM 'id';\n"),
        ] {
            let path = test_root(&format!("postgres-dump-{label}"));
            std::fs::write(
                &path,
                format!("-- PostgreSQL database dump\n{command}").as_bytes(),
            )
            .unwrap();
            assert!(validate_postgres_dump_file(&path).is_err());
            std::fs::remove_file(path).unwrap();
        }
    }




    #[tokio::test]
    async fn create_http_backup_contains_addon_related_data() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let parent = test_root("create");
        let install_dir = parent.join("install");
        let data_dir = parent.join("data");
        std::fs::create_dir_all(&install_dir).unwrap();
        std::fs::create_dir_all(data_dir.join("trusted-services/example.weather")).unwrap();
        std::fs::write(install_dir.join("server"), b"server binary").unwrap();
        std::fs::write(data_dir.join("signage.db"), b"sqlite with addon_storage").unwrap();
        std::fs::write(
            data_dir.join("trusted-services/example.weather/manifest.json"),
            b"staged manifest",
        )
        .unwrap();

        let db_path = parent.join("metadata.db");
        let db = crate::db::Database::open(db_path.to_str().unwrap()).unwrap();
        let old_cwd = std::env::current_dir().unwrap();
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        std::env::set_current_dir(&install_dir).unwrap();
        unsafe { std::env::set_var("SIGNAGE_DATA_DIR", &data_dir); }
        let app = Router::new()
            .route("/api/backups", post(create_backup))
            .with_state(BackupMetadataRepository::Sqlite(std::sync::Arc::new(db)));
        let response = app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/backups")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let body = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();

        std::env::set_current_dir(old_cwd).unwrap();
        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }

        assert_eq!(status, StatusCode::OK, "body={}", String::from_utf8_lossy(&body));
        let backup: crate::models::Backup = serde_json::from_slice(&body).unwrap();
        let archive_path = std::path::Path::new(&backup.file_path);
        assert!(archive_path.is_file());
        #[cfg(unix)]
        assert_eq!(std::fs::metadata(archive_path).unwrap().permissions().mode() & 0o777, 0o600);
        assert!(safe_archive::archive_contains_path(archive_path, std::path::Path::new("app/server")).unwrap());
        assert!(safe_archive::archive_contains_path(archive_path, std::path::Path::new("data/signage.db")).unwrap());
        assert!(safe_archive::archive_contains_path_prefix(
            archive_path,
            std::path::Path::new("data/trusted-services"),
        )
        .unwrap());
        assert_eq!(backup.size_bytes, std::fs::metadata(archive_path).unwrap().len());
        let _ = std::fs::remove_dir_all(parent);
    }

    #[tokio::test]
    async fn upload_http_registers_backup_without_restoring_it() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let parent = test_root("upload");
        let data_dir = parent.join("data");
        std::fs::create_dir_all(data_dir.join("backups")).unwrap();
        std::fs::write(data_dir.join("signage.db"), b"existing database").unwrap();
        let archive_path = parent.join("source.tar.gz");
        let archive_file = std::fs::File::create(&archive_path).unwrap();
        let encoder = GzEncoder::new(archive_file, Compression::default());
        let mut builder = Builder::new(encoder);
        append_test_file(&mut builder, "app/server", b"uploaded server");
        append_test_file(&mut builder, "data/signage.db", b"uploaded database");
        builder.into_inner().unwrap().finish().unwrap();
        let archive_bytes = std::fs::read(&archive_path).unwrap();

        let db_path = parent.join("metadata.db");
        let db = std::sync::Arc::new(crate::db::Database::open(db_path.to_str().unwrap()).unwrap());
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        unsafe { std::env::set_var("SIGNAGE_DATA_DIR", &data_dir); }
        let app = Router::new()
            .route("/api/backups/upload", put(upload_backup))
            .with_state(BackupMetadataRepository::Sqlite(db.clone()));
        let boundary = "backup-upload-boundary";
        let mut body = format!(
            "--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"uploaded.tar.gz\"\r\nContent-Type: application/gzip\r\n\r\n"
        )
        .into_bytes();
        body.extend_from_slice(&archive_bytes);
        body.extend_from_slice(format!("\r\n--{boundary}--\r\n").as_bytes());
        let response = app
            .clone()
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/backups/upload")
                    .header("content-type", format!("multipart/form-data; boundary={boundary}"))
                    .body(axum::body::Body::from(body.clone()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let _ = to_bytes(response.into_body(), 1024).await.unwrap();
        let second_response = app
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/backups/upload")
                    .header("content-type", format!("multipart/form-data; boundary={boundary}"))
                    .body(axum::body::Body::from(body))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(second_response.status(), StatusCode::CREATED);

        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }

        assert_eq!(status, StatusCode::CREATED);
        assert_eq!(std::fs::read(data_dir.join("signage.db")).unwrap(), b"existing database");
        let backups = db.list_backups().unwrap();
        assert_eq!(backups.len(), 2);
        assert!(std::path::Path::new(&backups[0].file_path).is_file());
        assert!(std::path::Path::new(&backups[1].file_path).is_file());
        #[cfg(unix)]
        {
            assert_eq!(std::fs::metadata(&backups[0].file_path).unwrap().permissions().mode() & 0o777, 0o600);
            assert_eq!(std::fs::metadata(&backups[1].file_path).unwrap().permissions().mode() & 0o777, 0o600);
        }
        assert_ne!(backups[0].file_path, backups[1].file_path);
        assert_eq!(backups[0].size_bytes, archive_bytes.len() as u64);
        assert_eq!(backups[1].size_bytes, archive_bytes.len() as u64);
        let _ = std::fs::remove_dir_all(parent);
    }

    #[tokio::test]
    async fn upload_http_rejects_invalid_archive_without_registering_it() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let parent = test_root("upload-invalid");
        let data_dir = parent.join("data");
        let backup_dir = data_dir.join("backups");
        std::fs::create_dir_all(&backup_dir).unwrap();
        let db_path = parent.join("metadata.db");
        let db = std::sync::Arc::new(crate::db::Database::open(db_path.to_str().unwrap()).unwrap());
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        unsafe { std::env::set_var("SIGNAGE_DATA_DIR", &data_dir); }
        let app = Router::new()
            .route("/api/backups/upload", put(upload_backup))
            .with_state(BackupMetadataRepository::Sqlite(db.clone()));
        let boundary = "invalid-backup-boundary";
        let body = format!(
            "--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"invalid.tar.gz\"\r\nContent-Type: application/gzip\r\n\r\nnot a tarball\r\n--{boundary}--\r\n"
        );
        let response = app
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/backups/upload")
                    .header("content-type", format!("multipart/form-data; boundary={boundary}"))
                    .body(axum::body::Body::from(body))
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let _ = to_bytes(response.into_body(), 1024).await.unwrap();

        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }

        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(db.list_backups().unwrap().is_empty());
        assert!(std::fs::read_dir(&backup_dir).unwrap().next().is_none());
        let _ = std::fs::remove_dir_all(parent);
    }

    #[tokio::test]
    async fn restore_http_confirmed_swaps_install_and_data_safely() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let parent = test_root("confirmed");
        let install_dir = parent.join("install");
        let data_dir = parent.join("data");
        std::fs::create_dir_all(&install_dir).unwrap();
        std::fs::create_dir_all(data_dir.join("backups")).unwrap();
        std::fs::write(install_dir.join("old.txt"), b"old install").unwrap();
        std::fs::write(data_dir.join("signage.db"), b"old database").unwrap();

        let archive_path = data_dir.join("backups/backup.tar.gz");
        let archive_file = std::fs::File::create(&archive_path).unwrap();
        let encoder = GzEncoder::new(archive_file, Compression::default());
        let mut builder = Builder::new(encoder);
        append_test_file(&mut builder, "app/restored.txt", b"restored install");
        append_test_file(&mut builder, "data/signage.db", b"restored database");
        append_test_file(
            &mut builder,
            "data/trusted-services/example.weather/manifest.json",
            b"restored manifest",
        );
        builder.into_inner().unwrap().finish().unwrap();

        let db_path = parent.join("metadata.db");
        let db = crate::db::Database::open(db_path.to_str().unwrap()).unwrap();
        db.insert_backup(&crate::models::Backup {
            id: "confirmed".to_string(),
            name: "Confirmed".to_string(),
            created_at: chrono::Utc::now().to_rfc3339(),
            file_path: archive_path.to_string_lossy().to_string(),
            size_bytes: std::fs::metadata(&archive_path).unwrap().len(),
        })
        .unwrap();

        let old_cwd = std::env::current_dir().unwrap();
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        let old_service_name = std::env::var_os("SIGNAGE_SERVICE_NAME");
        let old_service_kind = std::env::var_os("SIGNAGE_SERVICE_KIND");
        std::env::set_current_dir(&install_dir).unwrap();
        unsafe {
            std::env::set_var("SIGNAGE_DATA_DIR", &data_dir);
            std::env::set_var("SIGNAGE_SERVICE_NAME", "screentra-cast-test-no-such.service");
            std::env::set_var("SIGNAGE_SERVICE_KIND", "user");
        }
        let app = Router::new()
            .route("/api/backups/{id}", put(restore_backup))
            .with_state(BackupMetadataRepository::Sqlite(std::sync::Arc::new(db)));
        let response = app
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/backups/confirmed?confirm=true")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let status = response.status();
        let body = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();

        std::env::set_current_dir(old_cwd).unwrap();
        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }
        if let Some(value) = old_service_name {
            unsafe { std::env::set_var("SIGNAGE_SERVICE_NAME", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_SERVICE_NAME"); }
        }
        if let Some(value) = old_service_kind {
            unsafe { std::env::set_var("SIGNAGE_SERVICE_KIND", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_SERVICE_KIND"); }
        }

        assert_eq!(status, StatusCode::OK, "body={}", String::from_utf8_lossy(&body));
        let payload: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(payload["status"], "restored");
        assert_eq!(std::fs::read(install_dir.join("restored.txt")).unwrap(), b"restored install");
        assert_eq!(std::fs::read(data_dir.join("signage.db")).unwrap(), b"restored database");
        assert_eq!(
            std::fs::read(data_dir.join("trusted-services/example.weather/manifest.json")).unwrap(),
            b"restored manifest"
        );
        let pre_restore_dir = payload["result"]["pre_restore_dir"].as_str().unwrap();
        assert!(std::path::Path::new(pre_restore_dir).is_dir());
        let _ = std::fs::remove_dir_all(pre_restore_dir);
        let _ = std::fs::remove_dir_all(parent);
    }

    #[tokio::test]
    async fn backup_http_create_and_restore_round_trips_addon_state() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let parent = test_root("round-trip");
        let install_dir = parent.join("install");
        let data_dir = parent.join("data");
        let trusted_dir = data_dir.join("trusted-services/example.weather");
        let runtime_dir = data_dir.join("trusted-service-runtime/example.weather");
        std::fs::create_dir_all(&install_dir).unwrap();
        std::fs::create_dir_all(&trusted_dir).unwrap();
        std::fs::create_dir_all(&runtime_dir).unwrap();
        std::fs::write(install_dir.join("server"), b"original server").unwrap();
        std::fs::write(trusted_dir.join("manifest.json"), b"original manifest").unwrap();
        std::fs::write(trusted_dir.join("manifest.sig"), b"original manifest signature").unwrap();
        std::fs::write(trusted_dir.join("image.sig"), b"original image signature").unwrap();
        std::fs::write(trusted_dir.join("state.json"), b"{\"state\":\"staged\"}").unwrap();
        let original_runtime_record = serde_json::json!({
            "record_version": 1,
            "addon_id": "example.weather",
            "addon_version": "1.0.0",
            "image": "registry.example/weather",
            "image_digest": format!("sha256:{}", "a".repeat(64)),
            "capabilities": ["storage"],
            "storage_namespace": "example.weather",
            "api_namespace": "example.weather",
            "activation_instance": "activation-1",
            "state": "approved",
            "approved_by": "admin",
            "approved_at": "2026-10-15T00:00:00Z",
            "updated_at": "2026-10-15T00:00:00Z",
            "execution_enabled": false,
            "gates": [],
            "last_error": null
        });
        std::fs::write(
            runtime_dir.join("runtime.json"),
            serde_json::to_vec_pretty(&original_runtime_record).unwrap(),
        )
        .unwrap();

        let signage_db_path = data_dir.join("signage.db");
        let signage_db = crate::db::Database::open(signage_db_path.to_str().unwrap()).unwrap();
        signage_db
            .set_addon_storage(
                "example.weather",
                "settings",
                "{\"units\":\"metric\"}",
                "2026-10-15T00:00:00Z",
            )
            .unwrap();
        signage_db
            .record_audit_event(
                Some("trusted-service"),
                Some("service"),
                "trusted_service_database",
                Some("example.weather"),
                "succeeded",
                Some("activation_instance=activation-1;operation=put"),
                "2026-10-15T00:00:01Z",
            )
            .unwrap();
        drop(signage_db);

        let metadata_db_path = parent.join("metadata.db");
        let metadata_db = std::sync::Arc::new(
            crate::db::Database::open(metadata_db_path.to_str().unwrap()).unwrap(),
        );
        let old_cwd = std::env::current_dir().unwrap();
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        let old_service_name = std::env::var_os("SIGNAGE_SERVICE_NAME");
        let old_service_kind = std::env::var_os("SIGNAGE_SERVICE_KIND");
        std::env::set_current_dir(&install_dir).unwrap();
        unsafe {
            std::env::set_var("SIGNAGE_DATA_DIR", &data_dir);
            std::env::set_var("SIGNAGE_SERVICE_NAME", "screentra-cast-test-no-such.service");
            std::env::set_var("SIGNAGE_SERVICE_KIND", "user");
        }

        let create_app = Router::new()
            .route("/api/backups", post(create_backup))
            .with_state(BackupMetadataRepository::Sqlite(metadata_db.clone()));
        let create_response = create_app
            .oneshot(
                Request::builder()
                    .method("POST")
                    .uri("/api/backups")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(create_response.status(), StatusCode::OK);
        let backup: crate::models::Backup =
            serde_json::from_slice(&to_bytes(create_response.into_body(), 1024 * 1024).await.unwrap())
                .unwrap();

        let mutated_db = crate::db::Database::open(signage_db_path.to_str().unwrap()).unwrap();
        mutated_db
            .delete_addon_storage_namespace("example.weather")
            .unwrap();
        drop(mutated_db);
        std::fs::write(trusted_dir.join("manifest.json"), b"mutated manifest").unwrap();
        std::fs::remove_file(trusted_dir.join("manifest.sig")).unwrap();
        std::fs::remove_file(trusted_dir.join("image.sig")).unwrap();
        std::fs::remove_file(trusted_dir.join("state.json")).unwrap();
        std::fs::write(runtime_dir.join("runtime.json"), b"{\"state\":\"disabled\"}").unwrap();

        let restore_app = Router::new()
            .route("/api/backups/{id}", put(restore_backup))
            .with_state(BackupMetadataRepository::Sqlite(metadata_db));
        let restore_response = restore_app
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri(format!("/api/backups/{}?confirm=true", backup.id))
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        let restore_status = restore_response.status();
        let restore_body = to_bytes(restore_response.into_body(), 1024 * 1024).await.unwrap();

        std::env::set_current_dir(old_cwd).unwrap();
        if let Some(value) = old_data_dir {
            unsafe { std::env::set_var("SIGNAGE_DATA_DIR", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_DATA_DIR"); }
        }
        if let Some(value) = old_service_name {
            unsafe { std::env::set_var("SIGNAGE_SERVICE_NAME", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_SERVICE_NAME"); }
        }
        if let Some(value) = old_service_kind {
            unsafe { std::env::set_var("SIGNAGE_SERVICE_KIND", value); }
        } else {
            unsafe { std::env::remove_var("SIGNAGE_SERVICE_KIND"); }
        }

        assert_eq!(
            restore_status,
            StatusCode::OK,
            "body={}",
            String::from_utf8_lossy(&restore_body)
        );
        let restored_db = crate::db::Database::open(signage_db_path.to_str().unwrap()).unwrap();
        let storage = restored_db
            .get_addon_storage("example.weather", "settings")
            .unwrap()
            .unwrap();
        assert_eq!(storage, "{\"units\":\"metric\"}");
        let audit_events = restored_db.list_audit_events(10).unwrap();
        assert!(audit_events.iter().any(|event| {
            event.event_type == "trusted_service_database"
                && event.target.as_deref() == Some("example.weather")
                && event.outcome == "succeeded"
                && event
                    .detail
                    .as_deref()
                    .unwrap_or("")
                    .contains("activation_instance=activation-1;operation=put")
        }));
        assert_eq!(
            std::fs::read(trusted_dir.join("manifest.json")).unwrap(),
            b"original manifest"
        );
        assert_eq!(
            std::fs::read(trusted_dir.join("manifest.sig")).unwrap(),
            b"original manifest signature"
        );
        assert_eq!(
            std::fs::read(trusted_dir.join("image.sig")).unwrap(),
            b"original image signature"
        );
        assert_eq!(
            std::fs::read(trusted_dir.join("state.json")).unwrap(),
            b"{\"state\":\"staged\"}"
        );
        assert!(!trusted_dir.join("active").exists());
        let restore_payload: serde_json::Value = serde_json::from_slice(&restore_body).unwrap();
        let pre_restore_dir = restore_payload["result"]["pre_restore_dir"].as_str().unwrap();
        let _ = std::fs::remove_dir_all(pre_restore_dir);
        let _ = std::fs::remove_dir_all(parent);
    }

    #[tokio::test]
    async fn restore_http_dry_run_reports_addon_and_trusted_service_state() {
        let _guard = crate::PROCESS_ENV_TEST_LOCK
            .get_or_init(|| Mutex::new(()))
            .lock()
            .unwrap();
        let root = test_root("dry-run");
        let data_dir = root.join("data");
        std::fs::create_dir_all(data_dir.join("backups")).unwrap();
        let archive_path = data_dir.join("backups/backup.tar.gz");
        let archive_file = std::fs::File::create(&archive_path).unwrap();
        let encoder = GzEncoder::new(archive_file, Compression::default());
        let mut builder = Builder::new(encoder);
        append_test_file(&mut builder, "app/server", b"binary");
        append_test_file(&mut builder, "data/signage.db", b"sqlite");
        append_test_file(
            &mut builder,
            "data/trusted-services/example.weather/manifest.json",
            b"manifest",
        );
        builder.into_inner().unwrap().finish().unwrap();

        let db_path = root.join("metadata.db");
        let db = crate::db::Database::open(db_path.to_str().unwrap()).unwrap();
        db.insert_backup(&crate::models::Backup {
            id: "dry-run".to_string(),
            name: "Dry run".to_string(),
            created_at: chrono::Utc::now().to_rfc3339(),
            file_path: archive_path.to_string_lossy().to_string(),
            size_bytes: std::fs::metadata(&archive_path).unwrap().len(),
        })
        .unwrap();

        let old_cwd = std::env::current_dir().unwrap();
        let old_data_dir = std::env::var_os("SIGNAGE_DATA_DIR");
        std::env::set_current_dir(&root).unwrap();
        unsafe {
            std::env::set_var("SIGNAGE_DATA_DIR", &data_dir);
        }
        let app = Router::new()
            .route("/api/backups/{id}", put(restore_backup))
            .with_state(BackupMetadataRepository::Sqlite(std::sync::Arc::new(db)));
        let response = app
            .oneshot(
                Request::builder()
                    .method("PUT")
                    .uri("/api/backups/dry-run?dry_run=true")
                    .body(axum::body::Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = to_bytes(response.into_body(), 1024 * 1024).await.unwrap();
        let payload: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(payload["status"], "dry_run");
        assert_eq!(payload["report"]["contains_core_database"], true);
        assert_eq!(payload["report"]["contains_postgresql_dump"], false);
        assert_eq!(payload["report"]["contains_trusted_service_staging"], true);
        assert_eq!(payload["report"]["warnings"].as_array().unwrap().len(), 0);

        std::env::set_current_dir(old_cwd).unwrap();
        if let Some(value) = old_data_dir {
            unsafe {
                std::env::set_var("SIGNAGE_DATA_DIR", value);
            }
        } else {
            unsafe {
                std::env::remove_var("SIGNAGE_DATA_DIR");
            }
        }
        let _ = std::fs::remove_dir_all(root);
    }
}
